"""Per-run metrics, and the cross-run table that is the actual deliverable.

The mission asks for attempt cost and distillation cost to be reported
apart. They are two different claims -- "the skill made the agent cheaper"
and "the skill was cheap to produce" -- and a single token total answers
neither. Keeping them apart is why the distiller has its own counting
proxy: Vibe surfaces no per-call usage, so a separate endpoint is the only
place the split exists.

Everything here is derived from the event log, which is written whether or
not this runs. Nothing is recomputed from the graph or from a transcript,
so a metrics bug cannot corrupt the record it describes -- rerun it against
`runs/<run_id>.jsonl` and get the same numbers.

The cross-run table is append-only markdown. It is the artefact the
"clearly working" criteria are judged on, so it records the things that
decide whether a run counts -- in particular whether the arms were
identical apart from the skill, because a run where they were not can be
used for debugging and nothing else.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

RUNS_DIR = Path(__file__).resolve().parent.parent / "runs"
CROSS_RUN = RUNS_DIR / "cross-run.md"

_HEADER = (
    "| run | gpu | skill v | skill tok | arm | passed | attempts | "
    "converged | attempt tok (in/out) | distil tok (in/out) | turns | "
    "attempt s | distil s | steps | counts |\n"
    "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n"
)


@dataclass
class ArmMetrics:
    arm: str
    tests_passed: int = 0
    attempts: int = 0
    converged: bool = False
    turns: int = 0
    attempt_seconds: float = 0.0
    attempt_prompt_tokens: int = 0
    attempt_completion_tokens: int = 0
    distil_seconds: float = 0.0
    distil_prompt_tokens: int = 0
    distil_completion_tokens: int = 0
    steps_ingested: int = 0
    steps_with_reasoning: int = 0
    skill_versions: list[int] = field(default_factory=list)
    distillations: int = 0
    distillations_accepted: int = 0
    memory_tool_calls: int = 0
    per_attempt: list[dict] = field(default_factory=list)


@dataclass
class RunMetrics:
    run_id: str
    gpu: str
    model: str
    commit: str
    skill_version: int
    skill_approx_tokens: int
    skill_dir_sha: str
    arms_identical: bool
    known_differences: list[str]
    arms: dict[str, ArmMetrics]

    @property
    def counts_toward_clearly_working(self) -> bool:
        """A run only counts if the arms differed by the skill alone.

        Stated here rather than left to a reader of the table: the whole
        point of the criterion is that it is not re-litigated per run.
        """
        return self.arms_identical and not self.known_differences


def collect(events: list[dict], *, run_id: str, gpu: str, model: str,
            commit: str, skill_version: int, skill_approx_tokens: int,
            skill_dir_sha: str, arms_identical: bool,
            known_differences: list[str],
            distil_usage: dict[str, dict] | None = None) -> RunMetrics:
    """Fold the event log into per-arm numbers.

    `distil_usage` is the distillation proxy's own counters per arm, which
    only the runner can read -- everything else comes from events.
    """
    arms: dict[str, ArmMetrics] = {}

    def arm_of(event: dict) -> ArmMetrics:
        name = event.get("swarm") or "unknown"
        return arms.setdefault(name, ArmMetrics(arm=name))

    for event in events:
        kind = event.get("type")
        if kind == "ATTEMPT_DONE":
            arm = arm_of(event)
            arm.attempts += 1
            arm.turns += event.get("turns_used", 0) or 0
            arm.attempt_seconds += event.get("attempt_seconds", 0.0) or 0.0
            arm.attempt_prompt_tokens += event.get("attempt_prompt_tokens", 0) or 0
            arm.attempt_completion_tokens += (
                event.get("attempt_completion_tokens", 0) or 0)
            arm.tests_passed = max(arm.tests_passed,
                                   event.get("tests_passed", 0) or 0)
            arm.per_attempt.append({
                "attempt": event.get("attempt"),
                "skill_version": event.get("skill_version"),
                "tests_passed": event.get("tests_passed"),
                # Migration left to do, counted off the source. Carried
                # because `tests_passed` is 0 both for "not started" and
                # for "agent broke the package" -- 70% of graded attempts
                # -- so it is the only per-attempt number that separates
                # progress from damage. See orchestrator/surfaces.py.
                "v1_remaining": event.get("v1_remaining"),
                "turns": event.get("turns_used"),
                "seconds": event.get("attempt_seconds"),
                "prompt_tokens": event.get("attempt_prompt_tokens"),
                "completion_tokens": event.get("attempt_completion_tokens"),
                "ended_cleanly": event.get("ended_cleanly"),
            })
        elif kind == "INGESTED":
            arm = arm_of(event)
            arm.steps_ingested += event.get("steps", 0) or 0
            arm.steps_with_reasoning += event.get("with_reasoning", 0) or 0
        elif kind == "DISTILLED":
            arm = arm_of(event)
            arm.distillations += 1
            arm.distil_seconds += event.get("seconds", 0.0) or 0.0
            arm.memory_tool_calls += event.get("memory_tool_calls", 0) or 0
            if event.get("accepted"):
                arm.distillations_accepted += 1
                if event.get("version") is not None:
                    arm.skill_versions.append(event["version"])
        elif kind == "FILE_DONE":
            arm = arm_of(event)
            arm.converged = arm.converged or bool(event.get("success"))

    for name, usage in (distil_usage or {}).items():
        arm = arms.setdefault(name, ArmMetrics(arm=name))
        arm.distil_prompt_tokens = usage.get("prompt_tokens", 0)
        arm.distil_completion_tokens = usage.get("completion_tokens", 0)

    return RunMetrics(
        run_id=run_id, gpu=gpu, model=model, commit=commit,
        skill_version=skill_version, skill_approx_tokens=skill_approx_tokens,
        skill_dir_sha=skill_dir_sha, arms_identical=arms_identical,
        known_differences=sorted(known_differences), arms=arms,
    )


def write(metrics: RunMetrics, *, runs_dir: Path | None = None) -> Path:
    """One JSON file per run, beside its event log."""
    directory = runs_dir or RUNS_DIR
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{metrics.run_id}-metrics.json"
    payload = asdict(metrics)
    payload["counts_toward_clearly_working"] = metrics.counts_toward_clearly_working
    path.write_text(json.dumps(payload, indent=2, default=str))
    return path


def append_to_table(metrics: RunMetrics, *, path: Path | None = None) -> Path:
    """Add this run's rows to the cross-run table.

    Append-only, and it records whether the run counts. A table that only
    listed the numbers would let a debugging run -- one where warm had
    tools cold did not -- be read later as evidence.
    """
    target = path or CROSS_RUN
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        target.write_text(
            "# Cross-run summary\n\nAppend-only. A run counts toward "
            "\"clearly working\" only when `counts` is `yes`: the arms "
            "differed by the skill alone.\n\n" + _HEADER)
    elif _HEADER.splitlines()[0] not in target.read_text():
        with target.open("a") as handle:
            handle.write("\n" + _HEADER)

    counts = "yes" if metrics.counts_toward_clearly_working else "NO (debug)"
    rows = []
    for name in sorted(metrics.arms):
        a = metrics.arms[name]
        rows.append(
            f"| {metrics.run_id} | {metrics.gpu} | {metrics.skill_version} | "
            f"{metrics.skill_approx_tokens} | {a.arm} | {a.tests_passed} | "
            f"{a.attempts} | {'yes' if a.converged else 'no'} | "
            f"{a.attempt_prompt_tokens:,}/{a.attempt_completion_tokens:,} | "
            f"{a.distil_prompt_tokens:,}/{a.distil_completion_tokens:,} | "
            f"{a.turns} | {a.attempt_seconds:.0f} | {a.distil_seconds:.0f} | "
            f"{a.steps_ingested} ({a.steps_with_reasoning} w/ reasoning) | "
            f"{counts} |"
        )
    with target.open("a") as handle:
        handle.write("\n".join(rows) + "\n")
    return target


def summarise(metrics: RunMetrics) -> str:
    """The lines printed at the end of a run."""
    lines = [
        f"metrics: skill v{metrics.skill_version} "
        f"({metrics.skill_approx_tokens} approx tokens, "
        f"{metrics.skill_dir_sha}) | counts toward clearly-working: "
        f"{'YES' if metrics.counts_toward_clearly_working else 'NO'}"
    ]
    if metrics.known_differences:
        lines.append(f"  arms differed in {metrics.known_differences} -- "
                     f"debugging run only")
    for name in sorted(metrics.arms):
        a = metrics.arms[name]
        lines.append(
            f"  {a.arm}: {a.tests_passed} passed, {a.attempts} attempt(s), "
            f"{a.turns} turn(s), {a.attempt_seconds:.0f}s attempt / "
            f"{a.distil_seconds:.0f}s distil | attempt tokens "
            f"{a.attempt_prompt_tokens:,} in / "
            f"{a.attempt_completion_tokens:,} out | distil tokens "
            f"{a.distil_prompt_tokens:,} in / "
            f"{a.distil_completion_tokens:,} out"
        )
        if a.distillations:
            lines.append(
                f"    distillation: {a.distillations_accepted}/"
                f"{a.distillations} accepted, versions {a.skill_versions or '-'}, "
                f"{a.memory_tool_calls} memory tool call(s)"
            )
    return "\n".join(lines)
