"""The distillation turn: the warm model rewrites its own skill.

Once per attempt, off the clock. The model that just failed (or passed) is
given its current procedure and the tools to query what it did, and asked
to write a better procedure. Nothing here writes migration knowledge: the
prompt below contains no Pydantic API, no import path, no validator name.
If the skill ever contains the answer, the agent put it there.

FIVE DECISIONS, each with a failure behind it.

  * THE MODEL WRITES A FILE, NOT A FENCED BLOCK. A SKILL.md *is* a fenced
    ```yaml block, so asking for one inside a code fence means nesting
    fences, and the first thing that breaks is the parser on our side. It
    writes `SKILL.md` into its own working directory and we read it back.

  * THAT DIRECTORY IS NOT THE REPO. A distiller with `write_file` pointed
    at the agent's checkout would edit the code between attempts, and the
    next grading run would score edits no attempt made.

  * ITS OWN VIBE_HOME. The memory MCP server lives here and nowhere else,
    so warm's ATTEMPTS stay free of it -- that separation is the whole of
    KNOWN_ARM_DIFFERENCES being empty. It also has no skills directory: a
    distiller that could `/pydantic-v2-migration` itself would be reading
    its own output as an instruction.

  * ITS OWN COUNTING PROXY. Distillation tokens are reported separately
    from attempt tokens, and the only way to separate them is a different
    endpoint, because Vibe does not surface per-call usage.

  * AN INVALID PROPOSAL GETS THE VALIDATOR'S OWN WORDS BACK. Up to two
    repair turns, then the previous version stays live and the rejection is
    recorded. Paraphrasing a schema error loses the JSON pointer that says
    which field is wrong.
"""
from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any

from orchestrator import ingest, skills
from orchestrator.writers import AgentWriter

logger = logging.getLogger(__name__)

MAX_REPAIRS = 2
# Distillation is one model turn plus a few tool calls. Ten minutes is far
# past anything legitimate and short enough that a wedged turn does not eat
# a pod session.
DISTILL_TIMEOUT_S = 600.0

_MEMORY_TOOL_MARKERS = ("memory", "trace", "step", "neo4j")


def is_memory_tool(name: str) -> bool:
    return any(m in (name or "").lower() for m in _MEMORY_TOOL_MARKERS)


@dataclass
class DistillResult:
    """One distillation turn, whatever happened."""
    accepted: skills.SkillVersion | None
    rejection: skills.Rejection | None
    seconds: float
    repairs: int
    memory_tool_calls: int
    eligible_traces: int
    proposal_chars: int
    note: str = ""
    queries: list[str] = field(default_factory=list)

    @property
    def version(self) -> int | None:
        return self.accepted.version if self.accepted else None


def render_steps(steps: list[dict], *, limit: int = 120) -> str:
    """Traces as text, for a writer that cannot query the graph itself."""
    lines = []
    for st in steps[:limit]:
        thought = (st.get("thought") or "").strip().replace("\n", " ")
        action = (st.get("action") or "").strip()
        obs = (st.get("observation") or "").strip().replace("\n", " ")
        lines.append(f"  - [{'pass' if st.get('suite_passed') else 'fail'}] "
                     f"{thought[:300]}\n      action: {action[:200]}"
                     f"\n      result: {obs[:200]}")
    return "\n".join(lines)


def build_prompt(current: skills.SkillVersion, *, attempt: int,
                 tests_passed: int, suite_passed: bool, error: str | None,
                 eligible: list[dict], out_path: str,
                 steps: list[dict] | None = None,
                 has_graph_tools: bool = True) -> str:
    """What the distiller is told. Deliberately free of task knowledge.

    It states the job, the evidence available, the format, and the two
    things the grader rejects outright -- all of which the migrating agent
    is already told in its own prompt. It does not say what to write.
    """
    history = "\n".join(
        f"  - trace {t['id'][:8]}: {t['steps']} step(s), "
        f"tests_passed={int((t.get('metrics') or {}).get('tests_passed', 0))}, "
        f"suite_passed={bool(t.get('suite_passed'))}"
        for t in eligible[-12:]
    ) or "  (none yet -- this is the first attempt on this harness)"

    verdict = ("the full suite PASSED" if suite_passed
               else f"the suite FAILED with {tests_passed} test(s) passing")
    if has_graph_tools:
        evidence = (
            "  - Your own past attempts are recorded in a reasoning graph. "
            "You have\n    memory tools; use them to look up what you "
            "tried, what the reasoning\n    was, and which steps failed. "
            "Search for the errors you hit.")
    else:
        # A tool-less writer is handed a selection instead of choosing
        # one. Worth remembering when comparing the two writers.
        rendered = render_steps(steps or [])
        evidence = ("  - The reasoning steps from those attempts, in order:\n"
                    + (rendered or "    (none recorded yet)"))
    return f"""You have just finished attempt {attempt} of a coding task, and {verdict}.

Your job now is to improve the written procedure you work from, so that
your next attempt goes better. This is the only thing you carry between
attempts: you will not remember this conversation.

Evidence you can use:
{evidence}
  - {len(eligible)} past attempts are eligible to learn from:
{history}
{f"  - The failure your last attempt ended on:{chr(10)}```{chr(10)}{error[:1500]}{chr(10)}```" if error else ""}

Write the improved procedure to the file `{out_path}`. That file does
not exist yet -- create it.

FORMAT. It must be a valid AIP skill, and it will be schema-validated. Keep
the exact structure of the current version:
  - YAML frontmatter delimited by `---`, containing `name`, `description`,
    and `metadata.aip` with `spec`, `schemaId`, `version` and
    `derived_from_traces`.
  - `metadata.aip.version` must be exactly {current.version + 1}.
  - `name` must stay `{skills.SKILL_NAME}`.
  - The body must be exactly ONE fenced yaml block and nothing else --
    no prose before or after it. Put any commentary in YAML comments.
  - The whole file must stay under {skills.DEFAULT_MAX_TOKENS} tokens
    (about {skills.DEFAULT_MAX_TOKENS * 4} characters). The version above
    is {current.approx_tokens}, so you have about
    {max(skills.DEFAULT_MAX_TOKENS - current.approx_tokens, 0)} tokens of
    headroom. This is a HARD limit: a proposal over it is rejected
    outright and the previous version stays live, so an improvement you
    cannot fit is an improvement that never happens.
    If the headroom is small, MAKE ROOM: delete steps that did not help,
    merge steps that always run together, and cut anti-patterns that have
    not recurred. Rewriting to be denser is better than appending, and
    appending is not available to you near the limit.
  - **EVERY LIST ITEM MUST BE A PLAIN STRING.** Two ways that goes wrong,
    both of which have already cost a version here:

        - Leaving type: ignore comments        # WRONG: a colon makes
                                               # this a MAPPING
        - "Leaving type: ignore comments"      # right

        - "BaseSettings has moved" errors appear   # WRONG: text outside
                                                   # the closing quote
        - 'BaseSettings has moved errors appear'   # right

    THE RULE: an item is either entirely inside ONE pair of quotes, or has
    no quotes at all. Never quote part of it.

    The mistake that keeps recurring is quoting an error message inside a
    sentence. Both of these are REJECTED:

        - "some error text" appears in the output
        - the error "some error text" shows up

    Write it as one scalar instead:

        - 'some error text appears in the output'

    Use single quotes when the text contains a colon. Do not put double
    quotes inside a list item at all.

Here is a minimal valid example of the whole file. Match this shape:

---
name: {skills.SKILL_NAME}
description: One sentence on what this procedure does and when to use it.
metadata:
  aip:
    spec: "https://arxiv.org/abs/2606.04781"
    schemaId: "https://raw.githubusercontent.com/zach-blumenfeld/aip/v0.3a3/assets/aip-schemas/procedure.schema.json"
    version: {current.version + 1}
    derived_from_traces: []
---

```yaml
purpose: >
  What this procedure achieves, in a sentence or two.
trigger_when:
  - A short string saying when to use it
anti_patterns:
  - A short string saying what not to do
  - "A string with a colon: quoted, because YAML would otherwise read it as a mapping"
steps:
  - name: a-kebab-case-step-name
    description: >
      What to do, and how to tell whether it worked.
```

CONTENT. Write what you actually learned. A step you did not take, or a
claim you did not verify, makes the procedure worse for the next attempt.
If the last attempt regressed against an earlier one, say so in a comment
and go back to what worked. Two things are rejected by the grader however
green the tests go: re-pointing imports at `pydantic.v1`, and emptying a
function body so it still imports.

This is the current version, for you to improve:

<current_skill>
{current.text}
</current_skill>
"""


def repair_prompt(rejection: skills.Rejection, out_path: str,
                  expected_version: int) -> str:
    """The validator's own diagnostics, verbatim.

    Its output is JSON Lines with a JSON pointer per error; paraphrasing it
    loses the one thing that says which field is wrong.
    """
    return f"""The procedure you wrote was rejected and has NOT been saved.

Reason: {rejection.reason}

{rejection.detail[:2500]}

Fix it and write the corrected file to `{out_path}` again -- it has
been removed, so create it. Remember:
`metadata.aip.version` must be exactly {expected_version}, the body must be
exactly one fenced yaml block with no prose around it, and the whole file
must stay under {skills.DEFAULT_MAX_TOKENS} tokens.

Reading the error:

  - "is not of type 'string'" -> a list item has an unquoted colon, so
    YAML made it a mapping. Wrap the WHOLE item in quotes.
  - "failed to parse body YAML ... expected <block end>" -> a list item
    has text outside its closing quote, like
    `- "some quoted bit" and then more`. Quote the whole item or none of
    it.

Write every list item as one plain string. Do not use inner double
quotes; single-quote the item or rephrase.
"""


async def distill(
    *,
    workspace: Any,
    mem: Any,
    model: str,
    writer: Any | None = None,
    attempt: int,
    tests_passed: int,
    suite_passed: bool,
    error: str | None = None,
    max_repairs: int = MAX_REPAIRS,
) -> DistillResult:
    """Run one distillation turn and return what came of it.

    Never raises. It runs after the attempt is graded and the trace closed,
    so a distiller that dies costs a skill version, not a run -- and the
    previous version stays live, which is the safe direction.
    """
    started = time.monotonic()
    memory_calls = 0
    queries: list[str] = []
    repairs = 0
    proposal = ""

    try:
        # Scoped to THIS fixture. Unscoped, the first distillation on a
        # new codebase learns from the previous one's 25 traces.
        from orchestrator.manifest import FIXTURE_DIR
        eligible = await mem.eligible_traces(model=model,
                                             fixture=FIXTURE_DIR.name)
    except Exception as exc:
        logger.warning("distill: could not read eligible traces: %r", exc)
        eligible = []

    # Default: the agent writes its own skill. That is the mission's
    # claim, and swapping the writer changes what the run measures -- see
    # orchestrator/writers.py.
    writer = writer or AgentWriter(workspace)
    current = skills.current()
    out_path = writer.out_path()
    steps: list[dict] = []
    if not writer.uses_graph_tools and eligible:
        try:
            steps = await mem.trace_steps([t["id"] for t in eligible])
        except Exception as exc:
            logger.warning("distill: could not read trace steps: %r", exc)
    prompt = build_prompt(current, attempt=attempt, tests_passed=tests_passed,
                          suite_passed=suite_passed, error=error,
                          eligible=eligible, out_path=out_path,
                          steps=steps,
                          has_graph_tools=writer.uses_graph_tools)

    rejection: skills.Rejection | None = None
    for turn in range(max_repairs + 1):
        # Before every turn, including repairs: Vibe's write_file will not
        # overwrite an existing file, so the output path must be absent or
        # the turn cannot produce anything.
        try:
            proposal, entries = await writer.write(prompt, resume=turn > 0)
        except Exception as exc:
            return DistillResult(
                None, None, time.monotonic() - started, repairs, memory_calls,
                len(eligible), len(proposal),
                note=f"the distillation turn did not run: {exc!r}")

        # What it actually asked the graph, off its own stream. The mission
        # asks for this explicitly: "distillation doesn't use the graph" is
        # a finding, not a bug to hide.
        for step in ingest.parse_stream(entries).steps:
            if step.tool_name and is_memory_tool(step.tool_name):
                memory_calls += 1
                queries.append(step.action[:200])

        if os.environ.get("DISTILL_DEBUG"):
            for st in ingest.parse_stream(entries).steps:
                print(f"      [distill] {st.action[:90]} -> "
                      f"{'FAILED ' if st.failed else ''}{st.observation[:140]!r}")
        if not proposal.strip():
            rejection = skills.Rejection(
                reason="no_output",
                detail=f"the distiller wrote nothing to {out_path}",
                proposal="")
        else:
            outcome = skills.propose(
                proposal, derived_from=[t["id"] for t in eligible])
            if isinstance(outcome, skills.SkillVersion):
                return DistillResult(
                    outcome, None, time.monotonic() - started, repairs,
                    memory_calls, len(eligible), len(proposal),
                    queries=queries)
            rejection = outcome

        if turn < max_repairs:
            repairs += 1
            prompt = repair_prompt(rejection, out_path, current.version + 1)

    # KEEP THE EVIDENCE. Three distillations were rejected `invalid_schema`
    # in one run and the log held exactly that word -- no proposal, no
    # validator output, nothing to fix the prompt from. The rejected text
    # and the diagnostics are the only things that say WHY.
    if rejection is not None:
        try:
            # Under versions_dir(), which the tests monkeypatch into a
            # tmp sandbox. Rooted at REPO_ROOT instead, the test suite
            # wrote its own rejected proposals into runs/rejected/ and
            # they read as evidence from a real run.
            debug_dir = skills.versions_dir() / "rejected"
            debug_dir.mkdir(parents=True, exist_ok=True)
            stem = f"attempt{attempt}-v{current.version + 1}-{rejection.reason}"
            (debug_dir / f"{stem}.md").write_text(rejection.proposal or "")
            (debug_dir / f"{stem}.diagnostics.txt").write_text(rejection.detail or "")
        except Exception as exc:                      # never cost a run
            logger.warning("could not save rejected proposal: %r", exc)

    # Out of repair turns. The previous version stays live, which is why
    # `propose` never touches the live file until a proposal validates.
    return DistillResult(
        None, rejection, time.monotonic() - started, repairs, memory_calls,
        len(eligible), len(proposal), queries=queries,
        note=(f"kept v{current.version}: {rejection.reason} after "
              f"{repairs} repair turn(s)") if rejection else "")
