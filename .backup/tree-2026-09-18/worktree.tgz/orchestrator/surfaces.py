"""How much pydantic v1 is left in a tree.

WHY THIS EXISTS. The test suite is the oracle, and it has one blind spot
that makes it unusable as a PROGRESS measure: every one of the fixture's
445 tests imports the package, so if the package does not import the
score is 0 -- and 0 means two opposite things.

    migration not started yet   the package raises PydanticUserError on
                                import. This is the STARTING state.
    agent destroyed the code    the package raises IndentationError on
                                import. This is the FAILURE state.

Measured over 77 graded attempts: 70% scored exactly 0, 13% scored ~300,
17% scored >=420. Three states, and seven attempts in ten land in the one
that cannot distinguish progress from damage. No skill effect is visible
through that.

This counts what is left to migrate by reading the SOURCE instead of
running it. It is defined when the package does not import, does not
parse, or does not exist, so it grades an attempt that fixed 12 of 40
sites as progress rather than as nothing.

THE FLOOR IS NOT ZERO, and the number is only readable against it.
Measured on this fixture: the pre-migration source counts 64 and the
human's own merged answer still counts 3 -- two `response.json()` calls
inside generated-code string literals (httpx, nothing to do with
pydantic) and one unrelated `class Config`. So 64 -> 3 is a COMPLETED
migration. Anything that reports this number must report the reference's
count beside it, or 3 reads as "almost done" when it means "done".

It is NOT an oracle and must never be used as one: the count going to
zero does not mean the migration is correct, only that the v1 spellings
are gone. The suite remains the only thing that decides success. This
decides whether an attempt MOVED.
"""
from __future__ import annotations

import re

# One definition, shared by the fixture scorer (scripts/make_fixture.py)
# and by the running harness. Two copies would drift, and then "surfaces
# present in this fixture" and "surfaces left in this tree" would be
# different questions wearing the same name.
#
# Each entry is a v1-ONLY spelling: something that must change for the
# migration to be real. Patterns that also match valid v2 code would make
# the count bottom out above zero and stop being readable.
SURFACES: dict[str, str] = {
    "class Config": r"^\s*class Config\b",
    "Extra./allow_mutation": r"\bExtra\.|allow_mutation",
    "Field(const/regex/items)":
        r"Field\([^)]*\b(?:const|regex|allow_mutation|min_items|max_items)\b",
    "update_forward_refs": r"\bupdate_forward_refs\b",
    "parse_obj/parse_raw/parse_file": r"\b(?:parse_obj|parse_raw|parse_file)\b",
    ".dict()/.json()": r"\.dict\(\)|\.json\(\)",
    "@validator": r"@validator\b",
    "@root_validator": r"@root_validator\b",
    "BaseSettings from pydantic": r"from pydantic import[^\n]*\bBaseSettings\b",
    "conint/constr/etc": r"\bcon(?:int|str|float|list|bytes|decimal)\s*\(",
    "__fields__": r"\b__fields__\b",
    "GenericModel": r"\bGenericModel\b",
    "__root__": r"\b__root__\b",
    "from_orm/orm_mode": r"\bfrom_orm\b|\borm_mode\b",
    "json_encoders": r"\bjson_encoders\b",
    "construct()": r"\.construct\(",
    "schema()/schema_json()": r"\.schema\(\)|\bschema_json\(",
    "validate_arguments": r"\bvalidate_arguments\b",
    "pydantic.fields/ModelField": r"\bpydantic\.fields\b|\bModelField\b",
    "SecretField": r"\bSecretField\b",
    "pydantic.v1 shim": r"\bpydantic\.v1\b",
}

_COMPILED = {name: re.compile(p, re.M) for name, p in SURFACES.items()}


def count(files: dict[str, bytes], *, within: str | None = None) -> int:
    """Total v1-only constructs left across the tree.

    `within` restricts to a path prefix -- the package, normally. The
    TESTS are post-migration and full of v2 spellings; counting them
    would add a constant that never moves and hide the signal.
    """
    return sum(breakdown(files, within=within).values())


def breakdown(files: dict[str, bytes], *,
              within: str | None = None) -> dict[str, int]:
    """Per-surface counts, so a stalled attempt says WHICH thing it left.

    Binary files and undecodable bytes are skipped rather than fatal: this
    runs on whatever the agent's tree currently is, which at the moment of
    interest is a tree that does not even parse.
    """
    out: dict[str, int] = {}
    for path, blob in files.items():
        if not path.endswith(".py"):
            continue
        if within and within not in path:
            continue
        try:
            text = blob.decode("utf-8", "replace")
        except Exception:
            continue
        for name, pattern in _COMPILED.items():
            hits = len(pattern.findall(text))
            if hits:
                out[name] = out.get(name, 0) + hits
    return out
