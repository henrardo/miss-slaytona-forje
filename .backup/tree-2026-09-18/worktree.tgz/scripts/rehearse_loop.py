#!/usr/bin/env python3
"""Rehearse the whole warm loop locally, before any GPU is rented.

    scripts/rehearse_loop.py [--vibe PATH_TO_VIBE] [--keep]

WHY. Every plumbing bug this project has had was found on a rented GPU: a
hook with no shebang, an MCP client speaking the wrong HTTP dialect,
`tools` read instead of `tools_available`, a handler that raised inside its
own except clause, a read-only checkout that made thirteen graded attempts
meaningless. None of them needed a 119B model. Two H200s have now also been
lost overnight before running a single test, so GPU time is the scarcest
thing here and it should go on runs, not on plumbing.

So this drives the REAL loop -- `migrate_codebase`, unwrapped, the same
function the pod runs -- with three things swapped for local equivalents:

    the model    a scripted OpenAI-compatible server (tests/fake_model_server)
    the host     bash instead of ssh, a temp dir instead of /home/agent-*
    the grader   scripted pytest output instead of a Daytona sandbox

Everything else is the shipped code: real Vibe, real skill install, real
`/skill-name` loading, real stream parsing, real ingestion, real
distillation with its real validator, real metrics. If this passes, what
remains to be discovered on the pod is the model's behaviour -- which is
the only thing a pod is actually needed for.

The graph is real when NEO4J_URI is reachable and a recording stub
otherwise; the script says which it used, because "graph links were
verified" means nothing if the graph was a dictionary.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO))

from dotenv import load_dotenv

load_dotenv()

from orchestrator import distill as distill_mod
from orchestrator import metrics as metrics_mod
from orchestrator import skills
from orchestrator.events import EventBus
from orchestrator.sync import AttemptSync
from orchestrator.vibe_agent import migrate_codebase
from swarm.agent_workspace import AgentWorkspace, SwarmHost
from tests.fake_model_server import FakeModelServer, Turn


# --------------------------------------------------------------------------
# The three swaps
# --------------------------------------------------------------------------

class LocalHost(SwarmHost):
    """`SwarmHost` over bash, with /home/<user> mapped into a temp dir.

    Subclassed rather than reimplemented so that everything above it --
    install_skill's read-back, the fingerprint, the distillation
    environment -- is the code that runs on the pod, not a parallel copy.
    """

    def __init__(self, root: Path, vibe: Path, venv: Path,
                 model_url: str) -> None:
        super().__init__(host="local", port=0, identity=Path("/dev/null"))
        self.root, self.vibe, self.venv_path = root, vibe, venv
        # Passed explicitly, never taken from agent_workspace.MODEL_BASE_URL:
        # that is a DATACLASS DEFAULT, bound when the class was defined, so
        # patching the module attribute afterwards changes nothing and every
        # agent quietly dials 127.0.0.1:30000 instead. Cost the first
        # rehearsal run a 10-minute hang with four wedged Vibe processes.
        self.model_url = model_url

    def _map(self, command: str) -> str:
        command = command.replace("/home/", f"{self.root}/home/")
        # GNU coreutils flags the pod has and BSD/macOS does not. Shim-only
        # substitutions: the pod keeps the real command.
        return command.replace("base64 -w0", "base64")

    def run(self, command: str, *, timeout: float = 600.0, check: bool = True,
            **kw) -> subprocess.CompletedProcess:
        return subprocess.run(["bash", "-lc", self._map(command)],
                              capture_output=True, text=True, timeout=timeout)

    def _as(self, agent_user: str, command: str) -> str:
        """Run as the agent would see it, with HOME pointed at its own tree.

        On the pod this is `su - <agent>`, so `~` is the agent's home and
        the transcript dump (`~/.vibe/logs/session/*`) resolves correctly.
        Locally there is no su, and without this `~` expands to the
        OPERATOR's home: the dump then reads my own Vibe sessions, finds no
        assistant turn for the attempt, and every attempt aborts. Nine
        attempts ran and none completed before this was set.
        """
        # UNMAPPED on purpose: `_map` rewrites every "/home/" once, so
        # building the real path here would prefix the root twice and every
        # `cd` would fail into a directory that does not exist.
        home = f"/home/{agent_user}"
        return f"export HOME={home}; cd {home}; " + command

    def run_as(self, agent_user: str, command: str, **kw):
        return self.run(self._as(agent_user, command), **kw)

    def argv(self, command: str) -> list[str]:
        return ["bash", "-lc", self._map(command)]

    def argv_as(self, agent_user: str, command: str) -> list[str]:
        return self.argv(self._as(agent_user, command))

    def put(self, data: bytes, dst: str, *, mode: str = "600",
            owner: str | None = None) -> None:
        path = Path(self._map(dst))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        path.chmod(int(mode, 8))

    def gpu_description(self) -> str:
        return "none (local rehearsal)"


class LocalWorkspace(AgentWorkspace):
    """AgentWorkspace pointed at a local tree and a local Vibe."""

    def _vibe_command(self, prompt: str, *, resume: bool,
                      vibe_home: str | None = None,
                      cwd: str | None = None) -> str:
        home = vibe_home or f"{self.home}/.vibe"
        workdir = cwd or self.repo_path
        return (
            f"cd {workdir} && VIBE_HOME={home} "
            f"{self.host.vibe} --prompt {shlex.quote(prompt)} "
            f"--auto-approve --trust --output streaming < /dev/null"
        )

    def install_dependencies(self, install_command: str, **kw):
        return subprocess.CompletedProcess([], 0, "", "")

    @property
    def venv(self) -> str:
        return str(self.host.venv_path)


@dataclass
class ScriptedResult:
    """Mirrors orchestrator.sandbox.SandboxResult field for field.

    A shim that is missing a field fails at the first `emit` that reads it,
    ~200 lines into the attempt loop, which is a slow way to learn that the
    grader's contract has three members and not two.
    """
    exit_code: int
    output: str
    create_ms: float = 0.0


class ScriptedPool:
    """The grader, scripted. One verdict per call, last one repeats."""

    def __init__(self, verdicts: list[tuple[int, str]]) -> None:
        self.verdicts = verdicts
        self.calls = 0

    async def run_pytest(self, *, file_contents, test_command, cwd="/repo"):
        code, output = self.verdicts[min(self.calls, len(self.verdicts) - 1)]
        self.calls += 1
        return ScriptedResult(code, output)


class RecordingMemory:
    """A graph in a dictionary, for when Aura is not reachable."""

    def __init__(self) -> None:
        self.traces: dict[str, dict] = {}
        self.steps: list[dict] = []
        self.tool_calls: list[dict] = []
        self.messages: list[tuple[str, str]] = []
        self.skills_recorded: list[dict] = []
        self._n = 0

    def set_provenance(self, **props) -> None:
        self.provenance = props

    async def start_trace(self, session_id, task):
        self._n += 1
        tid = f"trace-{self._n}"
        self.traces[tid] = {"task": task, "steps": 0}
        return type("T", (), {"id": tid})()

    async def complete_trace(self, trace_id, *, outcome, **kw):
        self.traces[str(trace_id)]["outcome"] = outcome

    async def add_step(self, trace_id, *, thought, action, observation=None,
                       **kw):
        self.steps.append({"trace": str(trace_id), "thought": thought,
                           "action": action, "observation": observation})
        return type("S", (), {"id": f"step-{len(self.steps)}"})()

    async def record_tool_call(self, step_id, **kw):
        self.tool_calls.append({"step": str(step_id), **kw})

    async def add_message(self, session_id, role, content, **kw):
        self.messages.append((role, content))

    async def eligible_traces(self, *, model, schema=2.0):
        return [{"id": tid, "steps": t["steps"], "suite_passed": False,
                 "metrics": {"tests_passed": 0.0}}
                for tid, t in self.traces.items()]


# --------------------------------------------------------------------------
# The script the fake model follows
# --------------------------------------------------------------------------

def attempt_turns(*, edit: bool, finish_text: str) -> list[Turn]:
    """One attempt's worth of model behaviour."""
    turns = [
        Turn(reasoning="First I should see what is in this repo.",
             text="Looking at the codebase.",
             tools=[("bash", {"command": "ls -la"})]),
    ]
    if edit:
        turns.append(Turn(
            reasoning="config.py imports BaseSettings from pydantic. That "
                      "moved. I will change the import.",
            text="Editing config.py.",
            tools=[("write_file", {"file_path": "config.py",
                                   "content": "VALUE = 2\n"})]))
    turns.append(Turn(reasoning="I have made the change I intended.",
                      text=finish_text))
    return turns


VALID_SKILL = """---
name: pydantic-v2-migration
description: A procedure distilled from my own graded attempts at migrating a codebase to Pydantic v2.
metadata:
  aip:
    spec: "https://arxiv.org/abs/2606.04781"
    schemaId: "https://raw.githubusercontent.com/zach-blumenfeld/aip/v0.3a3/assets/aip-schemas/procedure.schema.json"
    version: {version}
    derived_from_traces: []
---

```yaml
purpose: >
  Migrate a codebase to Pydantic v2 so its own suite passes.
trigger_when:
  - Asked to migrate a codebase to Pydantic v2
steps:
  - name: read-the-first-error
    description: Run the suite and work the first failure, not the last.
  - name: change-one-thing
    description: Make one change, then re-run, so a regression is attributable.
```
"""

INVALID_SKILL = "Here is my improved skill!\n\nIt has no frontmatter at all.\n"


def distill_turns(out_path: str, *, first: str,
                  then: str | None = None) -> list[Turn]:
    """A distillation turn writes a file; a repair turn writes another.

    `out_path` must be ABSOLUTE: Vibe's WriteFileArgs.file_path is
    documented "must be absolute, not relative", and a relative one fails
    validation silently -- the tool errors, the file keeps its old
    contents, and the next thing anyone sees is the distiller rejected for
    proposing version 0 again. The real prompt hands the model an absolute
    path already; this makes the rehearsal match it.
    """
    turns = [Turn(reasoning="What did I try before, and what failed?",
                  text="Checking my past attempts.",
                  tools=[("neo4j-agent-memory_search_steps",
                          {"query": "pydantic migration failure"})]),
             Turn(reasoning="Now I will write the improved procedure.",
                  text="Writing the skill.",
                  tools=[("write_file", {"file_path": out_path,
                                         "content": first})]),
             # A turn with no tools ENDS the invocation. The repair loop is
             # a second invocation, not two turns of one -- so the script
             # has to stop here or both writes land in the same turn and
             # the second fails against the file the first just created.
             Turn(text="Written.")]
    if then is not None:
        turns += [
            Turn(reasoning="It was rejected. The validator says what is wrong.",
                 text="Fixing the format.",
                 tools=[("write_file", {"file_path": out_path,
                                        "content": then})]),
            Turn(text="Fixed."),
        ]
    return turns


# --------------------------------------------------------------------------

# The whole rehearsal is scripted, so anything slow is a bug in it.
REHEARSAL_DEADLINE_S = 300.0

CHECKS: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    CHECKS.append((name, bool(ok), detail))
    print(f"  {'PASS' if ok else 'FAIL'}  {name}"
          + (f"  -- {detail}" if detail and not ok else ""))


async def rehearse(vibe: Path, root: Path, model_url: str,
                   server: FakeModelServer) -> int:
    host = LocalHost(root, vibe, vibe.parent, model_url)
    host.server = server
    bus = EventBus(f"rehearsal-{int(time.time())}")

    spaces = {}
    for label in ("warm-0", "cold-0"):
        ws = LocalWorkspace(host=host, label=label, model="fake-model",
                            model_base_url=model_url)
        (root / f"home/agent-{label}").mkdir(parents=True, exist_ok=True)
        repo = root / f"home/agent-{label}/repo"
        repo.mkdir(parents=True, exist_ok=True)
        (repo / "config.py").write_text("VALUE = 1\n")
        ws.write_config(web_url=None)
        ws.init_history()
        spaces[label] = ws

    # ---- 0. the best-tree rollback, against real git ---------------------
    print("... checking the best-tree rollback", flush=True)
    probe = spaces["warm-0"]
    # Self-contained: this rehearsal never seeds a real repo, so the probe
    # makes its own tracked file rather than assuming the fixture's layout.
    # Assuming it wrote into a directory that did not exist, the redirect
    # failed silently and the check "passed" against an empty string.
    pkg = f"{probe.repo_path}/broken_probe.py"
    good = f"{probe.repo_path}/pkg_probe/__init__.py"
    probe.host.run_as(
        probe.user,
        f"mkdir -p {probe.repo_path}/pkg_probe && echo 'x = 1' > {good}",
        check=False)
    probe.init_history()
    check("a good tree can be checkpointed", probe.checkpoint("good state"))
    # Now break it the way the agents actually broke it: a syntax error in
    # an existing file, plus a NEW broken file that a plain reset would keep.
    probe.host.run_as(probe.user, f"printf 'def f():\nreturn 1\n' > {good}",
                      check=False)
    probe.host.run_as(probe.user, f"printf 'if True\n' > {pkg}", check=False)
    restored = probe.restore_best()
    body = probe.host.run_as(probe.user, f"cat {good}", check=False).stdout
    leftover = probe.host.run_as(
        probe.user, f"test -e {pkg} && echo yes || echo no",
        check=False).stdout.strip()
    check("the rollback restores the edited file", restored and "x = 1" in body,
          f"restored={restored} body={body.strip()!r}")
    check("the rollback also deletes files the bad attempt ADDED",
          leftover.endswith("no"),
          "a plain `git reset --hard` keeps untracked files, so the same "
          "ImportError would greet the next attempt")

    # ---- 1. install the whole skill package, verified as the agent -------
    print("... installing the skill package", flush=True)
    live = skills.current()
    installed = spaces["warm-0"].install_skill(live.files,
                                               name=skills.SKILL_NAME,
                                               version=live.version)
    check("skill package installs and reads back",
          installed["dir"] == live.dir_sha and installed["body"] == live.body_sha,
          f"{installed} vs dir={live.dir_sha} body={live.body_sha}")
    check("warm has a skills directory", spaces["warm-0"].has_skills_dir())
    check("cold has NO skills directory",
          not spaces["cold-0"].has_skills_dir())

    # ---- 2. arm parity ----------------------------------------------------
    print("... building the distillation environment", flush=True)
    spaces["warm-0"].enable_distillation(
        mcp_url="http://127.0.0.1:1/mcp", model_base_url=host.model_url)
    for ws in spaces.values():
        probe = ws.invoke_vibe("Reply with the single word: ready", timeout=120.0)
        if not ws.loaded_tools():
            # Say why, immediately. "0 tools" with no explanation is the
            # exact shape of run 9, which took a day to diagnose.
            print(f"    {ws.label} probe rc={probe.returncode}")
            print(f"    stdout: {(probe.stdout or '')[:300]}")
            print(f"    stderr: {(probe.stderr or '')[-600:]}")
    print("... fingerprinting both arms", flush=True)
    warm_fp = spaces["warm-0"].setup_fingerprint()
    cold_fp = spaces["cold-0"].setup_fingerprint()
    differences = {k: (warm_fp[k], cold_fp[k]) for k in warm_fp
                   if warm_fp[k] != cold_fp[k]}
    check("arms identical apart from the skill", not differences,
          f"differ in {sorted(differences)}")
    check("both arms loaded the same tools",
          warm_fp["tools"] == cold_fp["tools"] and bool(warm_fp["tools"]),
          f"warm={len(warm_fp['tools'])} cold={len(cold_fp['tools'])}")
    check("neither arm has a post_tool hook",
          not warm_fp["hook_files"] and not cold_fp["hook_files"])

    # ---- 3. the real attempt loop ----------------------------------------
    # Ordered log of what each arm was doing when, so the rehearsal can
    # assert that no distillation overlapped the other arm's attempt.
    timeline: list[tuple[str, str, float]] = []

    def mark(what: str, who: str) -> None:
        timeline.append((what, who, time.monotonic()))

    mem = RecordingMemory()
    mem.set_provenance(prov_model="fake-model", prov_gpu="none",
                       prov_commit="local", prov_writable=True)
    distilled: list[distill_mod.DistillResult] = []

    async def distiller(*, attempt, tests_passed, suite_passed, error):
        mark("distil-start", "warm-0")
        result = await distill_mod.distill(
            workspace=spaces["warm-0"], mem=mem, model="fake-model",
            attempt=attempt, tests_passed=tests_passed,
            suite_passed=suite_passed, error=error)
        distilled.append(result)
        # The same install-after-accept that run.py does, and for the same
        # reason: `propose` moves the live pointer on this machine, the
        # agent reads its own $VIBE_HOME. Rehearsing the loop without this
        # rehearses a loop that cannot close.
        if result.accepted is not None:
            spaces["warm-0"].install_skill(result.accepted.files,
                                           name=skills.SKILL_NAME,
                                           version=result.accepted.version)
        mark("distil-end", "warm-0")
        return result

    def emit_for(arm: str, label: str):
        async def emit(event_type, **kw):
            if event_type in ("ATTEMPT_START", "ATTEMPT_DONE"):
                mark(event_type.lower().replace("_", "-"), label)
            return await bus.emit(event_type, swarm=arm, agent=label, **kw)
        return emit

    # Attempt 1 fails, attempt 2 passes. The first distillation writes an
    # invalid skill then repairs it; the second writes a valid one.
    pool = ScriptedPool([
        (1, "E   ImportError: cannot import name 'BaseSettings'\n"
            "=== 8 passed, 25 failed in 1.2s ==="),
        (0, "=== 33 passed in 1.4s ==="),
    ])
    # The absolute path the distiller is told to write, as the agent's own
    # shell sees it.
    out_path = str(root) + spaces["warm-0"].distill_skill_path()
    # RELATIVE to whatever the copied package starts at. The rehearsal runs
    # against a copy of the REAL skill, which advances with every run, so
    # hard-coded version numbers rot the moment the agent distils.
    v0 = skills.current().version
    # TWO scripts, routed by what the prompt asks for. A flat queue drifts:
    # a repair turn re-runs the distiller, so the next attempt would be
    # served the distiller's leftovers -- observed, as the distiller being
    # handed `bash ls -la`.
    host.server.scripts = {
        "attempt": (
            attempt_turns(edit=True, finish_text="I changed the import.")
            + attempt_turns(edit=True,
                            finish_text="The migration is complete.")),
        "distil-1": distill_turns(out_path, first=INVALID_SKILL,
                                  then=VALID_SKILL.format(version=v0 + 1)),
        "distil-2": distill_turns(out_path, first=VALID_SKILL.format(version=v0 + 2)),
    }
    host.server._indices = {k: 0 for k in host.server.scripts}

    distil_calls = {"n": 0}

    last_distil = {"key": "distil-1"}

    def route(body: dict) -> str:
        text = json.dumps(body.get("messages") or [])
        # Match on the output path, which BOTH the first distillation
        # prompt and its repair prompts carry. Matching on "improve the
        # written procedure" sent every repair turn to the attempt script,
        # and the distiller was served `bash ls -la`.
        if out_path not in text:
            return "attempt"
        if "attempt 2" in text:
            last_distil["key"] = "distil-2"
        elif "attempt 1" in text:
            last_distil["key"] = "distil-1"
        # A repair prompt names neither attempt: it continues whichever
        # distillation is in progress.
        return last_distil["key"]

    host.server.router = route

    print("... running the real attempt loop", flush=True)
    # BOTH arms, through the real loop, sharing one barrier -- the
    # arrangement the pod runs, and the only way to test the ordering.
    sync = AttemptSync(["warm-0", "cold-0"])
    cold_pool = ScriptedPool([
        (1, "E   ImportError: cannot import name 'BaseSettings'\n"
            "=== 5 passed, 28 failed in 1.1s ==="),
        (1, "=== 9 passed, 24 failed in 1.2s ==="),
    ])

    async def run_arm(label: str, warm: bool):
        try:
            return await migrate_codebase(
                pool=(pool if warm else cold_pool),
                workspace=spaces[label], test_command="pytest -q",
                # Short: a rehearsal that can spin for half an hour is a
                # rehearsal nobody runs. Scripted attempts need seconds.
                deadline=time.monotonic() + REHEARSAL_DEADLINE_S,
                emit=emit_for("warm" if warm else "cold", label),
                mem=mem if warm else None,
                session_id=label if warm else None,
                baseline_signature="ImportError: BaseSettings",
                baseline_passed=0, agent_label=label,
                skill_name=skills.SKILL_NAME if warm else None,
                distiller=distiller if warm else None,
                sync=sync,
            )
        finally:
            sync.leave(label)

    result, cold_result = await asyncio.gather(
        run_arm("warm-0", True), run_arm("cold-0", False))

    check("the loop converged on the scripted pass", result.success,
          f"success={result.success} attempts={result.attempts}")
    check("two attempts ran", result.attempts == 2, f"{result.attempts}")

    # ---- 3b. distillation must not overlap the other arm's attempt ------
    #
    # Warm and cold share one SGLang server; per-stream throughput roughly
    # halves under contention. A distillation running during cold's
    # attempt would slow cold down, and that slowdown would appear in the
    # wall-clock comparison as though memory caused it.
    overlaps = []
    for what, who, when in timeline:
        if what != "distil-start":
            continue
        end = next((t for w, _, t in timeline if w == "distil-end" and t > when),
                   when)
        overlaps += [(when, t2, end) for w2, who2, t2 in timeline
                     if who2 == "cold-0" and w2 == "attempt-start"
                     and when < t2 < end]
    check("no distillation overlapped cold's attempt", not overlaps,
          f"{len(overlaps)} overlap(s)")

    seq = [(w, o) for w, o, _ in timeline
           if w in ("attempt-start", "attempt-done")]
    warm_n = sum(1 for w, o in seq if w == "attempt-start" and o == "warm-0")
    cold_n = sum(1 for w, o in seq if w == "attempt-start" and o == "cold-0")

    # Only WHILE BOTH ARMS ARE RUNNING. Warm converges on attempt 2 and
    # leaves the barrier; cold then keeps going alone until the deadline,
    # which is correct -- the arms are independent and stopping cold early
    # would censor its distribution. So the ordering property is asserted
    # over the prefix up to warm's last attempt, not over the whole run.
    # Whole rounds only. Warm's last attempt-done can land just before
    # cold's, so cutting at warm's final event leaves a half round -- that
    # is the two arms finishing within milliseconds of each other, not a
    # barrier failure.
    last_warm = max((i for i, (w, o) in enumerate(seq)
                     if o == "warm-0" and w == "attempt-done"), default=-1)
    prefix = seq[:((last_warm + 1) // 4) * 4]
    rounds_ok = bool(prefix) and all(
        sorted(w for w, _ in prefix[i:i + 2]) == ["attempt-start", "attempt-start"]
        and sorted(w for w, _ in prefix[i + 2:i + 4]) == ["attempt-done", "attempt-done"]
        and {o for _, o in prefix[i:i + 4]} == {"warm-0", "cold-0"}
        for i in range(0, len(prefix), 4))
    check("attempts are synchronised in rounds while both arms run",
          rounds_ok, f"{prefix}")
    check("the arms stayed in step while both were running",
          len(prefix) // 4 >= warm_n - 1 and warm_n > 0,
          f"warm ran {warm_n}, {len(prefix) // 4} whole synchronised round(s)")
    check("cold kept working after warm left", cold_n > warm_n,
          f"warm={warm_n} cold={cold_n} -- cold should not stop when warm does")

    # ---- 4. fresh sessions ------------------------------------------------
    resumed = [e for e in bus.events if e["type"] == "ATTEMPT_DONE"
               and e.get("resumed")]
    check("no attempt resumed a session", not resumed,
          f"{len(resumed)} resumed")

    # ---- 5. the skill reached the model, every attempt --------------------
    loaded = spaces["warm-0"].loaded_skill_text(skills.SKILL_NAME)
    check("the skill reached the model", loaded is not None)
    starts = [e for e in bus.events
              if e["type"] == "ATTEMPT_START" and e.get("agent") == "warm-0"]
    check("attempt 1 used the starting version and attempt 2 the distilled one",
          [e.get("skill_version") for e in starts] == [v0, v0 + 1],
          f"{[e.get('skill_version') for e in starts]}")
    # AND the file on the pod is the one that version names. The check above
    # passed for two runs while the loop was open: it read
    # skills.current(), so it confirmed the ORCHESTRATOR's pointer had
    # advanced and said nothing about what the agent could read. The bytes
    # in the agent's own skills directory are the only version that acts on
    # the model.
    on_pod = spaces["warm-0"]._skill_files_on_pod(
        f"{spaces['warm-0'].home}/.vibe/skills/{skills.SKILL_NAME}")
    final = skills.current()
    check("the improved skill reached the agent's own skills directory",
          on_pod.get("SKILL.md") == hashlib.sha256(
              final.files["SKILL.md"]).hexdigest()
          and spaces["warm-0"].installed_skill_version == final.version,
          f"pod has {str(on_pod.get('SKILL.md'))[:12]}, live v{final.version} "
          f"is {hashlib.sha256(final.files['SKILL.md']).hexdigest()[:12]}, "
          f"workspace says v{spaces['warm-0'].installed_skill_version}")
    cold_starts = [e for e in bus.events
                   if e["type"] == "ATTEMPT_START" and e.get("agent") == "cold-0"]
    check("cold never had a skill version",
          all(e.get("skill_version") is None for e in cold_starts),
          f"{ {e.get('skill_version') for e in cold_starts} }")

    # ---- 6. ingestion -----------------------------------------------------
    ingested = [e for e in bus.events if e["type"] == "INGESTED"]
    check("every attempt was ingested", len(ingested) == 2, f"{len(ingested)}")
    check("steps were written to the graph", len(mem.steps) > 0,
          f"{len(mem.steps)} steps")
    with_reasoning = [s for s in mem.steps if (s["thought"] or "").strip()]
    check("every step carries the model's own reasoning",
          len(with_reasoning) == len(mem.steps),
          f"{len(with_reasoning)}/{len(mem.steps)}")
    check("no step stored tool-argument JSON as its thought",
          not any((s["thought"] or "").lstrip().startswith("{")
                  for s in mem.steps))
    check("tool calls were recorded", len(mem.tool_calls) > 0,
          f"{len(mem.tool_calls)}")

    # ---- 7. distillation: rejection, repair, versioning -------------------
    check("distillation ran after each attempt", len(distilled) == 2,
          f"{len(distilled)}")
    for i, d in enumerate(distilled):
        if d.rejection is not None:
            print(f"    distillation {i}: {d.rejection.reason}")
            print(f"      detail: {d.rejection.detail[:400]}")
            print(f"      proposal head: {d.rejection.proposal[:160]!r}")
    check("an invalid skill was rejected and repaired",
          distilled and distilled[0].repairs == 1,
          f"repairs={distilled[0].repairs if distilled else 'n/a'} "
          f"{getattr(distilled[0].rejection, 'reason', '') if distilled else ''}")
    check("the repaired skill became the next version",
          distilled and distilled[0].version == v0 + 1,
          f"{distilled[0].version if distilled else None}")
    check("the second distillation advanced again",
          len(distilled) > 1 and distilled[1].version == v0 + 2,
          f"{distilled[1].version if len(distilled) > 1 else None}")
    check("the live skill advanced twice", skills.current().version == v0 + 2,
          f"v{skills.current().version}")
    check("the distiller queried the graph",
          all(d.memory_tool_calls > 0 for d in distilled),
          f"{[d.memory_tool_calls for d in distilled]}")
    check("the distiller never edited the repo",
          (root / "home/agent-warm-0/repo/config.py").read_text() != VALID_SKILL,
          "the distillation turn wrote into the agent's checkout")

    # ---- 8. metrics -------------------------------------------------------
    print("... collecting metrics", flush=True)
    run_metrics = metrics_mod.collect(
        bus.events, run_id=bus.run_id, gpu="none", model="fake-model",
        commit="local", skill_version=skills.current().version,
        skill_approx_tokens=skills.current().approx_tokens,
        skill_dir_sha=skills.current().dir_sha,
        arms_identical=not differences, known_differences=sorted(differences),
        distil_usage={"warm": {"prompt_tokens": 1, "completion_tokens": 1}})
    warm = run_metrics.arms.get("warm")
    check("metrics recorded both attempts",
          warm is not None and warm.attempts == 2)
    check("attempt and distillation time are separate",
          warm is not None and warm.attempt_seconds > 0
          and warm.distil_seconds > 0,
          f"attempt={getattr(warm, 'attempt_seconds', 0):.1f}s "
          f"distil={getattr(warm, 'distil_seconds', 0):.1f}s")
    check("the per-attempt table records the skill version used",
          warm is not None
          and [a["skill_version"] for a in warm.per_attempt] == [v0, v0 + 1],
          f"{[a['skill_version'] for a in warm.per_attempt] if warm else None} "
          f"expected {[v0, v0 + 1]}")
    table = metrics_mod.append_to_table(run_metrics,
                                        path=root / "cross-run.md")
    check("the cross-run table was written", table.exists())

    bus.close()
    return 0 if all(ok for _, ok, _ in CHECKS) else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--vibe", default=os.environ.get("REHEARSE_VIBE", ""),
                    help="path to a vibe binary (python 3.12+ venv)")
    ap.add_argument("--keep", action="store_true",
                    help="keep the temp tree for inspection")
    args = ap.parse_args()

    vibe = Path(args.vibe) if args.vibe else None
    if not vibe or not vibe.exists():
        print("ERROR: --vibe must point at a vibe binary. Vibe needs python "
              "3.12+, which this project's venv is not, so the rehearsal "
              "uses a separate one:\n"
              "  uv venv --python 3.13 /tmp/vibetest\n"
              "  VIRTUAL_ENV=/tmp/vibetest uv pip install mistral-vibe==2.25.4\n"
              "  scripts/rehearse_loop.py --vibe /tmp/vibetest/bin/vibe")
        return 2

    root = Path(tempfile.mkdtemp(prefix="rehearse-"))
    # The live skill is mutated by distillation, so the rehearsal works on
    # a COPY of the package. Running it must never advance the real skill.
    sandbox_skills = root / "skills"
    shutil.copytree(skills.SKILLS_DIR, sandbox_skills)
    skills.SKILLS_DIR = sandbox_skills
    skills.VALIDATOR = sandbox_skills / "_aip" / "validate.py"

    print(f"rehearsal root: {root}")
    print(f"vibe: {vibe}")
    script: list[Turn] = [Turn(text="ready")]
    with FakeModelServer(script) as server:
        code = asyncio.run(rehearse(vibe, root, server.base_url, server))

    print()
    failed = [(n, d) for n, ok, d in CHECKS if not ok]
    print(f"{len(CHECKS) - len(failed)}/{len(CHECKS)} checks passed")
    for name, detail in failed:
        print(f"  FAILED: {name}  {detail}")
    if args.keep:
        print(f"tree kept at {root}")
    else:
        shutil.rmtree(root, ignore_errors=True)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
