#!/usr/bin/env python3
"""Run a swarm against a repo, with the agents on a remote host.

    swarm/run.py --repo ./fixture --install "pip install -r requirements-v2.txt" \
                 --test "python -m pytest tests -q" --deadline-s 900 \
                 --ssh-host H --ssh-port P --ssh-key K

This file is deliberately thin. The attempt loop, the grading, the trace
keying, `observed_fix`, the shim and gutted-validator gates and every emitted
event are `orchestrator.vibe_agent.migrate_codebase`, unchanged and unwrapped
-- the same function, producing the same graph, in the same way. The only
difference from a local run is the Workspace it is handed: an AgentWorkspace
that runs Vibe over SSH on the swarm host instead of a LocalWorkspace running
it here.

An earlier version of this file had its own attempt loop, its own cruder
`tests_passed` and `error_signature`, and its own outcome strings. It produced
a different graph and would have drifted further with every fix applied to one
copy and not the other.

Where things run, and why:

  agents      the swarm host, one unix user each, home 0700, containing only
              the repo they were given. The harness is not on that machine.
  the model   the same host, at localhost:30000.
  the grader  a fresh Daytona sandbox, driven from HERE -- the one environment
              no agent has touched, which is what makes its verdict ground
              truth, and it keeps DAYTONA_API_KEY off the swarm host.
"""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import logging
import re
import socket
import subprocess
import sys
import time
import traceback
from collections import Counter
from pathlib import Path
from typing import Any

from daytona import AsyncDaytona
from dotenv import load_dotenv

load_dotenv()
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from neo4j_agent_memory import MemoryClient

from orchestrator.events import EventBus
from orchestrator.memory import ScopedMemory, build_settings, reset_graph
from orchestrator.sandbox import SandboxPool, install_cleanup_handlers
from orchestrator.run import (MAX_CONSECUTIVE_AGENT_FAILURES, _smoke_test_tool,
                              run_swarm)
from orchestrator import skills
from orchestrator.distill import distill
from orchestrator import metrics as metrics_mod
from orchestrator.sync import AttemptSync, NullSync
from orchestrator.writers import AgentWriter, ExternalWriter
from orchestrator.snapshot import load_state, pool_kwargs_from_state
from orchestrator.vibe_agent import MigrationResult, error_signature, migrate_codebase, tests_passed
from orchestrator.manifest import FIXTURE_DIR, load_manifest
from swarm.agent_workspace import AgentWorkspace, SwarmHost, repo_tarball


def _port_of(url: str) -> int:
    """The port an MCP url points at, for the local forward to mirror."""
    m = re.search(r":(\d+)", url.split("//", 1)[-1])
    if not m:
        raise ValueError(f"no port in {url!r}")
    return int(m.group(1))


class BlockingCallWatch(logging.Handler):
    """Counts asyncio's own "callback took too long" warnings.

    Run 12's whole concurrency failure was one `subprocess.run` inside an
    `async def`: `#running-req` never exceeded 1 across 1,032 scheduler
    samples while the endpoint happily served 4 concurrent requests at 543
    tok/s. Nothing in the harness noticed, because a blocked event loop looks
    exactly like a slow model.

    asyncio already detects this in debug mode -- it logs a WARNING whenever a
    callback exceeds `loop.slow_callback_duration`. It is off by default and
    goes to a logger nobody configured, so this attaches to it, keeps the
    worst offenders and makes the run say so at the end.
    """

    def __init__(self) -> None:
        super().__init__(logging.WARNING)
        self.hits: list[tuple[float, str]] = []

    def emit(self, record: logging.LogRecord) -> None:
        msg = record.getMessage()
        if "took" not in msg or "seconds" not in msg:
            return
        try:
            secs = float(msg.rsplit("took", 1)[1].split("seconds")[0].strip())
        except (IndexError, ValueError):
            secs = 0.0
        self.hits.append((secs, msg))

    def report(self) -> str:
        if not self.hits:
            return "event loop: no blocking callbacks over the threshold"
        worst = sorted(self.hits, reverse=True)[:3]
        lines = [f"BLOCKING EVENT LOOP: {len(self.hits)} callback(s) over the "
                 f"threshold -- agents cannot run concurrently while this happens"]
        lines += [f"     {s:.1f}s  {m[:150]}" for s, m in worst]
        return "\n".join(lines)

# After-the-clock graph enrichment. Generous, because it is real work on a
# long session, but finite: it must never be able to hold a run open.
ENTITY_TIMEOUT_S = 240.0

_HARNESS_BUGS = (TypeError, AttributeError, NameError, ImportError, AssertionError)


def control(host: SwarmHost, port: int, payload: dict) -> dict:
    """One request on the sidecar's control channel, over SSH.

    The sidecar holds the warm agents' ScopedMemory and the Neo4j credentials,
    and it lives on the swarm host beside the agents so the hook still reaches
    it over loopback. `set_trace` is how it learns which trace the current
    attempt belongs to -- in the local design that was an in-process call.
    """
    body = json.dumps(json.dumps(payload))
    out = host.run(
        f"printf %s {body} | python3 -c \"import socket,sys;"
        f"d=sys.stdin.read();s=socket.create_connection(('127.0.0.1',{port}),timeout=60);"
        f"s.sendall((d+chr(10)).encode());print(s.makefile().readline().strip())\"",
        check=False, timeout=120,
    ).stdout.strip()
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return {}


def proxy_usage(host: SwarmHost, base_url: str) -> dict:
    """Cumulative token counters from a counting proxy on the swarm host.

    Two of them, one per arm, because Vibe never surfaces per-call usage
    outside its own process -- the same reason the local design ran two."""
    out = host.run(
        f"python3 -c \"import urllib.request;"
        f"print(urllib.request.urlopen('{base_url}/usage', timeout=20).read().decode())\"",
        check=False, timeout=60).stdout.strip()
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return {}


class RemoteTraceBridge:
    """Tells the remote sidecar which trace an attempt belongs to.

    Locally, `step_memory.set_trace(agent, trace_id)` is a dict assignment.
    The sidecar is now on the swarm host, so the same call goes over SSH. The
    method names match `StepMemoryService` exactly, because migrate_codebase
    calls them without knowing which it has.
    """

    def __init__(self, host: SwarmHost, port: int) -> None:
        self._host, self._port = host, port

    def set_trace(self, agent: str, trace_id) -> None:
        control(self._host, self._port,
                {"control": "set_trace", "agent": agent, "trace_id": str(trace_id)})

    def clear_trace(self, agent: str) -> None:
        control(self._host, self._port, {"control": "clear_trace", "agent": agent})

    def set_pending_reasoning(self, agent: str, text: str, turn_id=None) -> None:
        # The remote sidecar receives reasoning through the hook's own
        # transcript reads; the streamed-entry path is local-only.
        return None

    def note_turn(self, agent: str, turn_id) -> None:
        return None

    def flush(self, timeout: float = 120.0) -> bool:
        """Block until the sidecar's write queue is empty.

        Called before anything reads the graph expecting this run's steps to
        be in it -- entity extraction and the summary both do."""
        r = control(self._host, self._port,
                    {"control": "flush", "timeout": timeout})
        return bool(r.get("ok", False))

    def summary(self) -> str:
        return control(self._host, self._port, {"control": "summary"}).get("summary", "")


@contextlib.contextmanager
def tunnels(host: SwarmHost, ports: dict[int, int]):
    """Local port forwards to the pod's loopback, for the duration of a block.

    The MCP servers bind 127.0.0.1 on the pod deliberately -- that is what
    keeps them off the network and their credentials out of reach. Forwarding
    is how the operator-side smoke test reaches them without loosening that,
    and it lets the real `_smoke_test_tool` run against them unchanged rather
    than a second copy of it living on the pod.
    """
    fwd: list[str] = []
    for local, remote in ports.items():
        fwd += ["-L", f"127.0.0.1:{local}:127.0.0.1:{remote}"]
    proc = subprocess.Popen(
        ["ssh", "-i", str(host.identity), "-p", str(host.port),
         "-o", "StrictHostKeyChecking=no", "-o", "ExitOnForwardFailure=yes",
         "-N", *fwd, f"{host.user}@{host.host}"],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
    )
    try:
        # ssh -N prints nothing on success, so there is no banner to wait for.
        # Poll the forwarded port instead of sleeping a guessed interval.
        deadline = time.monotonic() + 20
        for local in ports:
            while time.monotonic() < deadline:
                with socket.socket() as s:
                    s.settimeout(1.0)
                    if s.connect_ex(("127.0.0.1", local)) == 0:
                        break
                if proc.poll() is not None:
                    raise RuntimeError(
                        f"ssh forward died: {(proc.stderr.read() or b'').decode()[:200]}")
                time.sleep(0.25)
        yield
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


async def smoke_test_mcp(urls: dict[str, str]) -> list[str]:
    """Call one real tool on each MCP server and read the answer.

    `_smoke_test_tool` and `_SMOKE_TESTS` are imported, not reimplemented --
    the specs are the ones already chosen for these two servers, and the
    error-string checks are the ones written against the two live failures
    they were found by. Only the transport differs: the pod serves both over
    loopback streamable-HTTP, and `check_mcp_servers` skips those by design
    ("http/sse transports aren't started by us"), so it cannot cover them.

    This is the check that was missing when the memory server published its
    tools to nobody: the process was up and answering, the config listed it,
    and the model was handed no memory tools at all. A run with 22 steps
    written and 0 retrievals looks exactly like a model that chose not to
    read.
    """
    from mcp import ClientSession
    from mcp.client.streamable_http import streamablehttp_client

    problems: list[str] = []
    for name, url in urls.items():
        try:
            async with streamablehttp_client(url) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await asyncio.wait_for(session.initialize(), timeout=60)
                    tools = (await session.list_tools()).tools
                    if not tools:
                        problems.append(f"MCP {name!r} started but published no tools.")
                        continue
                    print(f"  MCP {name}: {len(tools)} tool(s)")
                    problems.extend(await _smoke_test_tool(session, name, tools))
        except Exception as exc:
            problems.append(
                f"MCP server {name!r} at {url} did not answer ({exc!r}). Its "
                f"tools will be silently absent from every agent's tool list."
            )
    return problems


# Differences between the arms that are KNOWN and tolerated. EMPTY, and it
# must stay empty for a run to count toward "clearly working".
#
# It briefly held three entries -- hook_files, config_names, tools -- all
# caused by warm writing to the graph during its attempts through a
# post_tool hook and the reasoning relay. Post-attempt ingestion removed
# the need for any of it (orchestrator/ingest.py), so warm's machine is now
# cold's machine plus a skill.
#
# Anything added back here is a confound in every warm-vs-cold number from
# that run, so a run with a non-empty list is a debugging run and is
# labelled as one in the output.
KNOWN_ARM_DIFFERENCES: frozenset[str] = frozenset()


def assert_arms_match(spaces: dict[str, AgentWorkspace],
                      labels: list[tuple[str, bool]]) -> list[str]:
    """Refuse to start unless warm and cold differ ONLY in the skill.

    The experiment's entire claim is a one-variable difference, and it has
    silently been a two-variable difference twice: the `web` MCP server was
    registered for warm only, and warm's task prompt carried three extra
    numbered steps. Both were found by reading code afterwards, and every
    token comparison from the runs in between was worthless.

    So it is asserted from the machine's own state, before the clock,
    rather than from a reading of this file. Hooks are included because the
    post_tool hook cost warm ~3.3s per tool call, which is wall-clock the
    deadline charges to warm alone; tool lists are included because a
    missing tool is a missing capability, not a missing memory.

    Skipped when only one arm is running -- there is nothing to compare.
    """
    warm_labels = [l for l, w in labels if w]
    cold_labels = [l for l, w in labels if not w]
    if not warm_labels or not cold_labels:
        return []
    warm_fp = spaces[warm_labels[0]].setup_fingerprint()
    cold_fp = spaces[cold_labels[0]].setup_fingerprint()
    differences = {k: (warm_fp[k], cold_fp[k]) for k in warm_fp
                   if warm_fp[k] != cold_fp[k]}
    unexpected = {k: v for k, v in differences.items()
                  if k not in KNOWN_ARM_DIFFERENCES}
    if unexpected:
        detail = "\n".join(f"    {k}: warm={w!r} cold={c!r}"
                           for k, (w, c) in sorted(unexpected.items()))
        raise RuntimeError(
            "warm and cold are not set up identically. The skill is the only "
            "permitted difference; these are not it:\n" + detail
        )
    if differences:
        print(f"  arms differ in {sorted(differences)} -- KNOWN, and a "
              f"confound in any warm-vs-cold number from this run. See "
              f"KNOWN_ARM_DIFFERENCES.")
        for k in sorted(differences):
            w, c = differences[k]
            print(f"      {k}: warm={_short(w)} cold={_short(c)}")
    else:
        print(f"  arms match exactly: {len(warm_fp['tools'])} tool(s) each, "
              f"hooks {warm_fp['hook_files'] or 'none'}, "
              f"mcp {warm_fp['config_names']}")
    return sorted(differences)


def _short(value, limit: int = 90) -> str:
    text = repr(value)
    return text if len(text) <= limit else text[:limit] + "...]"


async def agent_worker(*, ws: AgentWorkspace, warm: bool, pool: SandboxPool,
                       test_command: str, deadline: float, bus: EventBus,
                       bridge: RemoteTraceBridge, mem: ScopedMemory | None,
                       baseline_signature: str | None, baseline_passed: int,
                       results: list, skill_name: str | None = None,
                       package_path: str | None = None,
                       distiller: Any | None = None,
                       usage_probe: Any | None = None,
                       sync: Any | None = None) -> MigrationResult:
    """Retries transient infrastructure failures; reports harness bugs loudly.

    Same split as the local orchestrator's agent_worker, and for the same
    measured reason: one Daytona "Failed to remove sandbox" ended warm-0's
    entire run while cold completed 8 attempts, and the summary read "WARM 0/0
    converged" as though memory had made the agent do nothing.
    """
    arm = "warm" if warm else "cold"

    async def emit(event_type: str, **kw):
        return await bus.emit(event_type, swarm=arm, agent=ws.label, **kw)

    best = MigrationResult(False, 0)
    consecutive_failures = 0

    try:
        return await _attempt_until_done(
            ws=ws, warm=warm, pool=pool, test_command=test_command,
            deadline=deadline, emit=emit, mem=mem,
            baseline_signature=baseline_signature,
            baseline_passed=baseline_passed, results=results,
            skill_name=skill_name, package_path=package_path,
            distiller=distiller,
            usage_probe=usage_probe, sync=sync, best=best,
            consecutive_failures=consecutive_failures)
    finally:
        # ALWAYS, on every exit: converged, clock expired, harness bug,
        # cancelled by run_swarm. An agent that stops without leaving the
        # barrier strands the other arm waiting for an attempt that will
        # never come.
        if sync is not None:
            sync.leave(ws.label)


async def _attempt_until_done(*, ws, warm, pool, test_command, deadline, emit,
                              package_path=None,
                              mem, baseline_signature, baseline_passed,
                              results, skill_name, distiller, usage_probe,
                              sync, best, consecutive_failures):
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            results.append((ws.label, warm, best))
            return best
        try:
            result = await migrate_codebase(
                pool=pool,
                workspace=ws,
                test_command=test_command,
                deadline=deadline,
                emit=emit,
                mem=mem,
                session_id=ws.label if warm else None,
                baseline_signature=baseline_signature,
                baseline_passed=baseline_passed,
                # No step_memory: nothing writes to the graph during an
                # attempt any more. `agent_label` stays -- it names the
                # agent in ingestion's own log lines.
                step_memory=None,
                agent_label=ws.label if warm else None,
                skill_name=skill_name,
                package_path=package_path,
                distiller=distiller,
                usage_probe=usage_probe,
                sync=sync,
            )
            results.append((ws.label, warm, result))
            return result
        except _HARNESS_BUGS as exc:
            print(f"  [{ws.label}] HARNESS BUG, not retrying: {exc!r}")
            traceback.print_exc()
            result = MigrationResult(False, 0)
            results.append((ws.label, warm, result))
            return result
        except Exception as exc:
            # DO NOT emit() from this handler. An earlier version of this
            # clause called emit("ATTEMPT_FAILED", ...), which orchestrator.
            # events.EVENT_TYPES does not declare, so make_event raised
            # ValueError from inside the handler for a Daytona 404 -- run 8's
            # entire cold arm died there, 0 attempts, while warm ran the full
            # clock. The local agent_worker prints and backs off and emits
            # nothing; this is that code, not a variation on it.
            consecutive_failures += 1
            if consecutive_failures >= MAX_CONSECUTIVE_AGENT_FAILURES:
                print(
                    f"  [{ws.label}] {exc!r} -- "
                    f"{consecutive_failures} consecutive failures, giving up on this agent"
                )
                traceback.print_exc()
                result = MigrationResult(False, best.attempts)
                results.append((ws.label, warm, result))
                return result
            print(
                f"  [{ws.label}] {exc!r} -- retrying "
                f"({consecutive_failures}/{MAX_CONSECUTIVE_AGENT_FAILURES})"
            )
            await asyncio.sleep(min(30.0, 2.0 ** consecutive_failures))


async def main_async(args, watch=None) -> int:
    if not args.no_loop_debug:
        asyncio.get_running_loop().slow_callback_duration = 0.1
    host = SwarmHost(host=args.ssh_host, port=args.ssh_port,
                     identity=Path(args.ssh_key))
    run_id = f"swarm-{int(time.time())}"
    bus = EventBus(run_id)
    bridge = RemoteTraceBridge(host, args.sidecar_port)
    repo = Path(args.repo).resolve()

    if args.reset_memory:
        # Same flag, same function as the local run: measure what the warm
        # agents build for each other WITHIN one run, rather than a graph that
        # has accumulated across runs. Both are real; they are different claims.
        deleted = await reset_graph()
        print(f"--reset-memory: deleted {deleted} node(s) from the shared graph")

    baseline_summary = control(host, args.sidecar_port, {"control": "summary"})
    usage_before = {"warm": proxy_usage(host, args.warm_proxy),
                    "cold": proxy_usage(host, args.cold_proxy)}

    # Preflight, before the clock: a dead memory server or sidecar is
    # indistinguishable at run time from "the model chose not to use memory",
    # which is the failure this project has already had 40 times.
    problems = []
    if not control(host, args.sidecar_port, {"control": "summary"}):
        problems.append(f"step-memory sidecar not answering on :{args.sidecar_port}")
    # A urlopen() GET used to stand in for this. It passed while the memory
    # server answered Vibe's handshake with 406 and the model was handed zero
    # memory tools -- the run then reported 22 steps written and 0 retrievals,
    # which reads as a model that chose not to retrieve. Call the tools.
    def _local(url: str, port: int) -> str:
        return re.sub(r"//127\.0\.0\.1:\d+", f"//127.0.0.1:{port}", url)

    try:
        with tunnels(host, {18811: _port_of(args.mcp_url),
                            18813: _port_of(args.web_url)}):
            problems += await smoke_test_mcp({
                "neo4j-agent-memory": _local(args.mcp_url, 18811),
                "web": _local(args.web_url, 18813),
            })
    except Exception as exc:
        problems.append(f"could not reach the pod's MCP servers to test them: {exc!r}")
    for name, url in (("warm", args.warm_proxy), ("cold", args.cold_proxy)):
        if not proxy_usage(host, url):
            problems.append(f"{name} counting proxy not answering at {url}")
    for problem in problems:
        print(f"PREFLIGHT: {problem}")
    if problems:
        return 1

    gpu = host.gpu_description()
    commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                            capture_output=True, text=True).stdout.strip() or "unknown"
    print(f"gpu: {gpu} | harness: {commit}")
    print(f"repo: {repo}")
    tar = repo_tarball(repo, exclude=(".git", "__pycache__", ".venv",
                                      ".pytest_cache", "reference_v2"))
    print(f"tarball: {len(tar):,} bytes")

    # `--swarm-size N` is N agents PER ARM, so the smallest both-arms run is
    # already 2 agents sharing one endpoint. On a single pod that is enough to
    # make them contend: run 12 saw warm-0 abort with "vibe completed no
    # assistant turn" while cold-0 was mid-attempt, which is the documented
    # under-load failure. `--arms warm` / `--arms cold` runs one arm at a
    # time so the comparison is between two clean runs instead of two agents
    # timesharing a GPU.
    want = {"both": (True, False), "warm": (True,), "cold": (False,)}[args.arms]
    labels = [(f"warm-{i}", True) for i in range(args.swarm_size) if True in want] + \
             [(f"cold-{i}", False) for i in range(args.swarm_size) if False in want]
    # The skill the warm arm starts this run on. Read once: every warm agent
    # must begin from the same version, or "which skill produced this result"
    # has as many answers as there are agents.
    live_skill = (skills.archived(args.skill_version)
                  if args.skill_version is not None else skills.current())
    if args.skill_version is not None:
        print(f"skill PINNED to v{args.skill_version}"
              + ("" if args.no_distill else
                 "  WARNING: distillation is on, so this version will be "
                 "superseded mid-run and the comparison is not controlled"))
    if args.no_distill:
        print("distiller: disabled  (the skill cannot change during this run)")
    elif args.distill_writer == "agent":
        print("distiller: the agent's own model  (self-improvement)")
    else:
        print(f"distiller: {args.distill_writer}  (EXTERNAL model: this run "
              f"does not measure self-improvement)")
    print(f"skill: v{live_skill.version} | dir {live_skill.dir_sha} | "
          f"body {live_skill.body_sha} | {len(live_skill.files)} file(s) | "
          f"{live_skill.approx_tokens} approx tokens | "
          f"derived from {len(live_skill.derived_from)} trace(s)")
    skill_shas: dict[str, str] = {}

    spaces: dict[str, AgentWorkspace] = {}
    for label, warm in labels:
        ws = AgentWorkspace(host=host, label=label, model=args.model,
                            model_base_url=args.warm_proxy if warm else args.cold_proxy,
                            auto_compact_threshold=args.auto_compact)
        ws.seed(tar)
        # A pristine commit, so there is always a floor to fall back to
        # when an attempt breaks the tree. Both arms, before anything else.
        ws.init_history()
        ws.clear_session_logs()
        ws.write_config(web_url=args.web_url)
        r = ws.install_dependencies(args.install)
        if r.returncode != 0:
            print(f"  {label}: install FAILED: {(r.stderr or '')[-200:]}")
        if warm:
            # The skill, before anything else warm gets. Installed into this
            # agent's own VIBE_HOME, so cold has no skills directory at all
            # rather than a disabled one -- the same shape as its missing
            # memory server, and it is re-verified on every run.
            installed = ws.install_skill(live_skill.files,
                                         name=skills.SKILL_NAME,
                                         version=live_skill.version)
            if (installed["dir"] != live_skill.dir_sha
                    or installed["body"] != live_skill.body_sha):
                raise RuntimeError(
                    f"{label}: the installed skill hashes "
                    f"{installed} but the live skill is dir="
                    f"{live_skill.dir_sha} body={live_skill.body_sha}. The "
                    f"agent would run against a different procedure than the "
                    f"one this run records."
                )
            skill_shas[label] = installed["body"]
            # NO enable_memory HERE ANY MORE, and that is the design.
            #
            # Warm used to get the neo4j-agent-memory MCP server, a
            # post_tool hook and the reasoning relay for its attempts. All
            # three existed to write the graph WHILE the agent worked, and
            # all three were warm-only: ~16 extra tools, two hooks.toml
            # files, ~3.3s of hook latency per tool call, and a relay in
            # Vibe's stdout pipeline. Every one of those is a difference
            # between the arms that is not memory, charged to warm by a
            # wall-clock deadline both arms share.
            #
            # The graph is now written after the attempt, from the stream
            # Vibe already emitted -- see orchestrator/ingest.py. So warm's
            # machine is cold's machine plus a skill, and the memory server
            # moves to the distillation turn, which is the only place the
            # model needs to query the graph.
            # The distiller's own environment: separate VIBE_HOME (so the
            # memory MCP server exists nowhere near an attempt), separate
            # working directory (so it cannot edit the checkout between
            # attempts) and separate endpoint (so its tokens are counted
            # apart).
            ws.enable_distillation(mcp_url=args.mcp_url,
                                   model_base_url=args.distill_proxy)
            ws.invoke_vibe("Reply with the single word: ready", timeout=300.0)
        else:
            # Verified every run, not assumed. "Cold never sees a skill" is a
            # claim about this machine, and the cheap way to be wrong about it
            # is to change where skills are installed and leave the old path
            # behind on a reused pod.
            if ws.has_skills_dir():
                raise RuntimeError(
                    f"{label} is a COLD agent and has a skills directory. "
                    f"Cold must have no skill and no graph; this run would "
                    f"compare warm against a cold arm that also had one."
                )
            # Both arms probe, so `loaded_tools` has a meta.json to read
            # and the tool lists can actually be compared. Without it the
            # comparison silently passes on two empty lists -- which is how
            # warm-only `web` survived two runs.
            ws.invoke_vibe("Reply with the single word: ready", timeout=300.0)
        # Fill the tree/transcript cache before the clock. Without this the
        # first attempt pays ~14s of blocking ssh inside the event loop --
        # see AgentWorkspace.refresh().
        ws.prime()
        spaces[label] = ws
        print(f"  {label} seeded{' (memory)' if warm else ''}")

    arm_differences = assert_arms_match(spaces, labels)
    # AFTER the fingerprint, which reads the probe session's meta.json for
    # the tool list. Dropping the probe first would leave nothing to read.
    for ws in spaces.values():
        ws.clear_session_logs()

    # The starting state, so attempt 1's trace is keyed on the error the suite
    # actually begins with rather than on the task description -- the same
    # reason the local run.py computes a baseline.
    probe = spaces[labels[0][0]]
    base = await pool_baseline(probe, args.test, args.install)
    baseline_signature, baseline_passed = base
    print(f"baseline: {baseline_passed} passing | {baseline_signature or '(none)'}")

    state = load_state()
    async with AsyncDaytona() as client, MemoryClient(build_settings()) as mem_client:
        pool = SandboxPool(client, run_id=run_id, **pool_kwargs_from_state(state))
        install_cleanup_handlers(pool)
        deadline = time.monotonic() + args.deadline_s
        results: list = []

        # Stamped onto every trace this run writes. See
        # ScopedMemory.set_provenance for why it cannot live in `metrics`.
        provenance = {
            "prov_model": args.model,
            "prov_gpu": gpu,
            "prov_commit": commit,
            "prov_writable": all(ws.checkout_is_writable()
                                 for ws in spaces.values()),
            # WHICH codebase. Without it a distiller on a new fixture
            # learns from the old fixture's traces -- measured: 25 of them
            # on the very first distillation, before the new fixture had
            # written any.
            "prov_fixture": FIXTURE_DIR.name,
        }
        print(f"provenance: {provenance}")
        if not provenance["prov_writable"]:
            print("  WARNING: at least one checkout is READ-ONLY -- agents "
                  "cannot edit source; this run is not a fair test")

        def _scoped(client, label, prov):
            m = ScopedMemory(client, user_identifier=label)
            m.set_provenance(**prov)
            return m

        def distiller_for(label: str, scoped: ScopedMemory):
            """One distillation turn for this agent, bound to its own
            workspace and memory scope.

            A closure rather than arguments threaded through
            migrate_codebase: the attempt loop should know that something
            happens after an attempt, not how a skill is written.
            """
            writer = writers_by_label[label]

            async def run(*, attempt: int, tests_passed: int,
                          suite_passed: bool, error: str | None):
                # No seeding. `distill` calls `clear_distilled` before every
                # turn, because Vibe's write_file refuses to overwrite an
                # existing file -- seeding the output path is precisely what
                # made every distillation fail in the first rehearsal.
                outcome = await distill(
                    workspace=spaces[label], mem=scoped, model=args.model,
                    writer=writer,
                    attempt=attempt, tests_passed=tests_passed,
                    suite_passed=suite_passed, error=error,
                )
                # AND PUT IT ON THE POD. Without this the loop was open:
                # `propose` writes the accepted version to the
                # orchestrator's disk and moves the live pointer, but the
                # agent reads $VIBE_HOME/skills, which was last written at
                # run setup. So attempt N+1 re-read the SAME procedure while
                # the event log said it was on the new one -- the skill could
                # never improve within a run, which is exactly what the
                # can't-one-shot-it task is meant to measure.
                if outcome.accepted is not None:
                    ws = spaces[label]
                    got = ws.install_skill(outcome.accepted.files,
                                           name=skills.SKILL_NAME,
                                           version=outcome.accepted.version)
                    if got["body"] != outcome.accepted.body_sha:
                        # Do not fail the run: the attempt loop continues on
                        # whatever install_skill last verified, and a loud
                        # line beats a silent version mismatch.
                        print(f"  {label}: distilled v"
                              f"{outcome.accepted.version} did not install "
                              f"cleanly ({got} vs body="
                              f"{outcome.accepted.body_sha}); the next "
                              f"attempt runs on v"
                              f"{ws.installed_skill_version}")
                return outcome
            return run

        scopes = {label: _scoped(mem_client, label, provenance)
                  for label, w in labels if w}
        # Built here, not inside the closure, so the run can read the
        # external writer's own token counters afterwards. An OpenAI call
        # does not pass through the counting proxy, so without this the
        # distillation cost of an external writer reports as ZERO -- which
        # reads as a distiller that was free rather than one that was
        # never measured.
        writers_by_label = {
            label: (AgentWriter(spaces[label])
                    if args.distill_writer == "agent"
                    else ExternalWriter(args.distill_writer))
            for label, w in labels if w
        }

        # One barrier across BOTH arms. With a single arm there is nothing
        # to synchronise and NullSync keeps the call sites uniform.
        running = [label for label, _ in labels]
        arms_present = {w for _, w in labels}
        sync = (AttemptSync(running) if len(arms_present) > 1 else NullSync())

        def tasks_for(warm: bool) -> list:
            return [asyncio.ensure_future(agent_worker(
                ws=spaces[label], warm=warm, pool=pool, test_command=args.test,
                deadline=deadline, bus=bus, bridge=bridge,
                mem=scopes.get(label) if warm else None,
                baseline_signature=baseline_signature,
                baseline_passed=baseline_passed, results=results,
                # Warm only, and it is the ONLY thing warm's prompt carries
                # that cold's does not. Cold has no skills directory, so the
                # prefix would be a stray token rather than a load.
                package_path=load_manifest().get("package_path"),
                skill_name=skills.SKILL_NAME if warm else None,
                # Cold never distils: it has no skill to improve and no
                # graph to read. Verified every run by assert_arms_match.
                distiller=(None if args.no_distill else
                           (distiller_for(label, scopes[label]) if warm else None)),
                # Sampled at each attempt boundary, and charged to
                # off_clock -- the harness measuring, not the agent working.
                usage_probe=(lambda url=(args.warm_proxy if warm
                                         else args.cold_proxy):
                             proxy_usage(host, url)),
                sync=sync,
            )) for label, w in labels if w is warm]

        # `run_swarm` unchanged from the local orchestrator: the moment one
        # agent in a swarm converges, the rest of THAT swarm is cancelled
        # rather than left grinding out the deadline. The arms stay
        # independent, so warm stopping early does not touch cold.
        stop = not args.no_stop_for_victory
        await asyncio.gather(
            run_swarm("warm", tasks_for(True), stop_on_success=stop),
            run_swarm("cold", tasks_for(False), stop_on_success=stop))
        swept = await pool.sweep()

        # Entities, once, AFTER the agents' clock has stopped and while the
        # client is still open -- the same two calls, in the same order, as
        # the local run. Messages are stored during the run with
        # extract_entities=False because extraction is an LLM round-trip and
        # inline it cost warm 45s per attempt; and nothing in the package
        # reads ReasoningStep.thought, which is where the substance is on a
        # coding task, so link_step_entities covers that gap.
        # The hook queues its writes (see StepMemoryService._queue), so drain
        # them before anything reads the graph. link_step_entities walks
        # ReasoningStep.thought; a step still sitting in the queue is a step
        # it cannot link, and the run would under-report without saying so.
        if not bridge.flush():
            print("  WARNING: the step-memory write queue did not drain -- "
                  "entity extraction and the counts below are incomplete")
        # BOUNDED. Both of these are OpenAI round trips -- one per message
        # for extraction -- and they run AFTER the measured window, so a
        # slow or rate-limited key cannot change a result but can stall the
        # run indefinitely. One did: the event log showed FILE_DONE at
        # t=214 and the process was still inside this block 18 minutes
        # later, blocked in SSL, holding up an A/B sweep.
        #
        # Nothing in the distillation loop reads these -- the distiller uses
        # search_steps and trace_steps -- so a timeout costs entity edges
        # and is recorded as such.
        entities_extracted, steps_linked = 0, 0
        for label, warm in labels:
            if not warm:
                continue
            scoped = ScopedMemory(mem_client, user_identifier=label)
            try:
                stats = await asyncio.wait_for(
                    scoped.extract_entities_from_session(label),
                    timeout=ENTITY_TIMEOUT_S)
                entities_extracted += sum(v for v in stats.values() if isinstance(v, int))
            except asyncio.TimeoutError:
                print(f"  entity extraction for {label} exceeded "
                      f"{ENTITY_TIMEOUT_S:.0f}s and was abandoned -- the "
                      f"run's own numbers are unaffected, the graph has "
                      f"fewer entity edges")
            except Exception as exc:
                print(f"  entity extraction failed for {label}: {exc!r}")
            try:
                steps_linked += await asyncio.wait_for(
                    scoped.link_step_entities(label),
                    timeout=ENTITY_TIMEOUT_S)
            except asyncio.TimeoutError:
                print(f"  step entity linking for {label} exceeded "
                      f"{ENTITY_TIMEOUT_S:.0f}s and was abandoned")
            except Exception as exc:
                print(f"  step entity linking failed for {label}: {exc!r}")

    # Did the skill actually reach the model? Installed, hashed and prefixed
    # are three separate things that can each succeed while the agent runs
    # with no procedure at all -- the same silent shape as run 9's memory
    # server, which was configured, up, answering, and handed the model zero
    # tools. Read off the agent's own transcript, after the clock.
    # Checked against the version THAT ATTEMPT started on, which is not the
    # version the run started on. Once distillation worked, the two
    # diverged by design: run 10 began on v5 and its three attempts loaded
    # v5, v6 and v7. Comparing against `live_skill` reported "skill v5
    # reached 0/1 warm agent(s)" -- a false negative, and the exact reading
    # this check exists to rule out.
    skill_loaded: dict[str, bool] = {}
    last_version = {                         # label -> version of its last attempt
        e["agent"]: e.get("skill_version")
        for e in bus.events if e["type"] == "ATTEMPT_START"
    }
    for label, warm in labels:
        if not warm:
            continue
        loaded = spaces[label].loaded_skill_text(skills.SKILL_NAME)
        served = skills.identify(loaded) if loaded else None
        want = last_version.get(label)
        skill_loaded[label] = served is not None and served == want
        if loaded is None:
            print(f"  {label}: SKILL NEVER LOADED -- no skill tool result in "
                  f"the transcript. Vibe did not treat the prompt as an "
                  f"invocation; the agent worked with no procedure.")
        elif served is None:
            print(f"  {label}: skill loaded but its text matches NO archived "
                  f"version -- Vibe served something that is not a version "
                  f"this run wrote, so what the agent read is unknown.")
        elif served != want:
            print(f"  {label}: last attempt started on v{want} but the "
                  f"transcript served v{served} -- the install after "
                  f"distillation did not reach the agent before it ran.")
        else:
            print(f"  {label}: skill v{served} reached the model on its last "
                  f"attempt (this run ran v"
                  f"{live_skill.version}..v{served})")

    summary = control(host, args.sidecar_port, {"control": "summary"})
    # THE SIDECAR AND THE HOOK MUST BE SILENT NOW. Nothing writes to the
    # graph during an attempt any more, so a non-zero count here means a
    # hooks.toml survived on a reused pod and warm is paying per-tool-call
    # latency cold does not -- exactly the confound this removed.
    live_hook_writes = summary.get("steps_written", 0) - baseline_summary.get("steps_written", 0)
    live_injections = summary.get("context_returned", 0) - baseline_summary.get("context_returned", 0)
    if live_hook_writes or live_injections:
        print(f"  WARNING: the step hook is still live -- {live_hook_writes} "
              f"write(s) and {live_injections} injection(s) during the "
              f"attempts. Warm paid per-tool-call latency cold did not, and "
              f"this run cannot be compared.")
    bus.close()

    print("\n" + "=" * 60)
    print(f"hardware: {gpu} | model: {args.model}")
    for arm_warm in (True, False):
        rows = [r for r in results if r[1] is arm_warm]
        key = "warm" if arm_warm else "cold"
        after = proxy_usage(host, args.warm_proxy if arm_warm else args.cold_proxy)
        d_in = after.get("prompt_tokens", 0) - usage_before[key].get("prompt_tokens", 0)
        d_out = after.get("completion_tokens", 0) - usage_before[key].get("completion_tokens", 0)
        name = "WARM (shared memory)" if arm_warm else "COLD (no memory)  "
        print(f"{name}: {sum(1 for r in rows if r[2].success)}/{args.swarm_size} converged"
              f" | {sum(r[2].attempts for r in rows)} attempts"
              f" | errors cleared {max((r[2].errors_cleared for r in rows), default=0)}"
              f" | best tests passing {max((r[2].best_passed for r in rows), default=0)}"
              f" | in {d_in:,} / out {d_out:,}")

    graded = sum(1 for e in bus.events if e["type"] == "ATTEMPT_DONE")
    oracle = sum(1 for e in bus.events if e["type"] == "SANDBOX_CREATED")
    if watch is not None:
        print(f"     {watch.report()}")
    print(f"\nGATE {'ok' if graded and oracle else 'FAILED'}: {graded} attempt(s) "
          f"graded by {oracle} real Daytona run(s); {swept} sandbox(es) swept")
    # What ingestion wrote, off the clock, from each attempt's own stream.
    # This replaces the step-hook counters: the hook is gone, and reporting
    # its always-zero numbers would read as "warm's graph is empty".
    ingested = [e for e in bus.events if e["type"] == "INGESTED"]
    steps_written = sum(e.get("steps", 0) for e in ingested)
    with_reasoning = sum(e.get("with_reasoning", 0) for e in ingested)
    print(f"     ingestion (off the clock): {steps_written} step(s) from "
          f"{len(ingested)} attempt(s), {with_reasoning} with the model's own "
          f"reasoning, {sum(e.get('failed_tool_calls', 0) for e in ingested)} "
          f"failed tool call(s) recorded")
    if skill_loaded:
        final = skills.current()
        # Started..ended, because a run with distillation on does not have
        # "the" version -- naming only the starting one made a working loop
        # look like a broken one.
        print(f"     skill started v{live_skill.version} "
              f"({live_skill.approx_tokens} approx tokens), ended v"
              f"{final.version} ({final.approx_tokens}); the version each "
              f"agent started its last attempt on reached "
              f"{sum(skill_loaded.values())}/{len(skill_loaded)} warm agent(s)")
    print(f"     entities extracted after the clock stopped: {entities_extracted} "
          f"from messages, {steps_linked} TOUCHED edge(s) from reasoning steps")
    if any(w for _, w in labels) and steps_written == 0:
        print("     INGESTION WROTE NOTHING -- warm's graph is empty, so the "
              "next distillation has nothing to learn from and warm == cold.")
    elif steps_written and with_reasoning == 0:
        print("     every ingested step has an EMPTY thought. search_steps "
              "embeds thought+action, so this graph is searchable only by "
              "what was typed. That is the bug ingestion exists to fix.")
    # Metrics last, derived from the event log rather than from anything
    # accumulated along the way -- rerunnable against runs/<id>.jsonl, so a
    # bug here cannot corrupt the record it describes.
    # Where the distillation tokens come from depends on WHO wrote the
    # skill: the agent's turns go through the pod's counting proxy, an
    # external model's do not and are counted by the writer itself.
    distil_usage = {}
    for label, warm in labels:
        if not warm:
            continue
        writer = writers_by_label.get(label)
        own = getattr(writer, "usage", None)
        distil_usage["warm"] = (dict(own) if own is not None
                                else proxy_usage(host, args.distill_proxy))
        break
    run_metrics = metrics_mod.collect(
        bus.events, run_id=run_id, gpu=gpu, model=args.model, commit=commit,
        skill_version=live_skill.version,
        skill_approx_tokens=live_skill.approx_tokens,
        skill_dir_sha=live_skill.dir_sha,
        arms_identical=not arm_differences,
        known_differences=list(arm_differences),
        distil_usage=distil_usage,
    )
    metrics_path = metrics_mod.write(run_metrics)
    table_path = metrics_mod.append_to_table(run_metrics)
    print(metrics_mod.summarise(run_metrics))
    print(f"event log: runs/{run_id}.jsonl | metrics: {metrics_path} | "
          f"table: {table_path}")
    return 0 if (graded and oracle) else 1


async def pool_baseline(ws: AgentWorkspace, test_command: str,
                        install_command: str) -> tuple[str | None, int]:
    """The pristine suite's own verdict, from the agent's own environment."""
    out = ws.host.run_as(
        ws.user, f"cd {ws.repo_path} && {ws.venv}/bin/{test_command} 2>&1 | tail -40",
        check=False, timeout=900).stdout
    return error_signature(out), tests_passed(out)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--repo", required=True)
    p.add_argument("--install", required=True, help="the repo's own dependency install command")
    p.add_argument("--test", required=True, help="the repo's own test command")
    p.add_argument("--deadline-s", type=float, default=900.0)
    p.add_argument("--swarm-size", type=int, default=1,
                   help="agents PER ARM; --swarm-size 1 --arms both is 2 agents.")
    p.add_argument("--no-stop-for-victory", action="store_true",
                   help="let both arms run the full deadline even after one "
                        "converges. Required for measurement runs: stopping "
                        "early censors the winner's distribution and leaves "
                        "the other agents' undefined.")
    p.add_argument("--no-loop-debug", action="store_true",
                   help="disable asyncio debug mode and the blocking-call guard.")
    p.add_argument("--arms", choices=("both", "warm", "cold"), default="both",
                   help="which arm(s) to run. One arm per run avoids two "
                        "agents contending for a single endpoint.")
    p.add_argument("--model", default="Qwen/Qwen3-14B")
    # Vibe's own default (200,000) assumes a large-context model and never
    # fires before a 32k model's own limit does; 24000 is the Qwen3-14B
    # figure. It has to track the served model's context window, so it is a
    # flag rather than a constant -- Mistral Small 4 reports 128,000.
    p.add_argument("--auto-compact", type=int, default=24000,
                   help="Vibe auto_compact_threshold; size to the model's context.")
    p.add_argument("--ssh-host", required=True)
    p.add_argument("--ssh-port", type=int, required=True)
    p.add_argument("--ssh-key", required=True)
    p.add_argument("--mcp-url", default="http://127.0.0.1:8811/mcp")
    p.add_argument("--web-url", default="http://127.0.0.1:8813/mcp",
                   help="web_lookup MCP server; registered for BOTH arms.")
    p.add_argument("--sidecar-port", type=int, default=8812)
    p.add_argument("--reset-memory", action="store_true",
                   help="Wipe the Neo4j graph before starting.")
    p.add_argument("--warm-proxy", default="http://127.0.0.1:8821")
    p.add_argument("--cold-proxy", default="http://127.0.0.1:8822")
    # A THIRD counting proxy, for the distillation turn alone. Vibe never
    # surfaces per-call usage, so a separate endpoint is the only place
    # "what did the skill cost to produce" can be read apart from "what
    # did the attempt cost".
    p.add_argument("--distill-proxy", default="http://127.0.0.1:8823")
    # WHO WRITES THE SKILL. "agent" is the mission's claim -- the warm
    # agent improves its own procedure on the served model. Naming an
    # external model instead changes the result from "the agent improved
    # itself" to "a stronger model distilled a procedure from its
    # traces", which is a different claim and must be reported as one.
    # The writer is stamped into every run's metrics for that reason.
    # HOLD THE SKILL CONSTANT. Pins warm to an archived version instead of
    # whatever is live, so a run measures one skill rather than a moving
    # one. Pair with --no-distill or the pinned version is superseded by
    # the first acceptance and the run stops being a controlled one.
    p.add_argument("--skill-version", type=int, default=None,
                   help="install this archived skill version instead of the "
                        "live one (skills/versions/vNNN-*.md).")
    p.add_argument("--no-distill", action="store_true",
                   help="skip the distillation turn. Required when pinning "
                        "a version, so the skill under test cannot change "
                        "underneath the run.")
    p.add_argument("--distill-writer", default="agent",
                   help="'agent' (the warm model, via Vibe and its memory "
                        "tools) or an OpenAI model id such as gpt-5, which "
                        "is handed the traces in its prompt instead.")
    args = p.parse_args()
    watch = BlockingCallWatch()
    if not args.no_loop_debug:
        # asyncio's debug mode is what surfaces a blocked loop at all. 0.1s is
        # far below anything legitimate here -- every real wait in this
        # harness is awaited, so a callback holding the loop for a tenth of a
        # second is a bug, not load.
        logging.getLogger("asyncio").addHandler(watch)
        logging.getLogger("asyncio").setLevel(logging.WARNING)
    rc = asyncio.run(main_async(args, watch), debug=not args.no_loop_debug)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
