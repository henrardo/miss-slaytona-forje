"""Metrics must keep attempt cost and distillation cost apart.

They answer two different questions -- "did the skill make the agent
cheaper" and "what did the skill cost to produce" -- and one combined
total answers neither. The whole reason the distiller has its own counting
proxy is that Vibe surfaces no per-call usage, so a separate endpoint is
the only place the split exists.

The other property here is that a run which cannot be compared says so.
This project has already produced two warm-vs-cold comparisons that were
worthless (warm-only `web`; warm-only prompt steps) and were read as
results for days afterwards.
"""
from __future__ import annotations

import json

from orchestrator import metrics as m


def _events() -> list[dict]:
    return [
        {"type": "ATTEMPT_START", "swarm": "warm", "attempt": 1, "skill_version": 0},
        {"type": "ATTEMPT_DONE", "swarm": "warm", "attempt": 1,
         "tests_passed": 12, "turns_used": 9, "attempt_seconds": 310.0,
         "attempt_prompt_tokens": 120_000, "attempt_completion_tokens": 4_000,
         "skill_version": 0, "ended_cleanly": True},
        {"type": "INGESTED", "swarm": "warm", "attempt": 1, "steps": 9,
         "with_reasoning": 9, "tool_calls": 8, "failed_tool_calls": 1},
        {"type": "DISTILLED", "swarm": "warm", "attempt": 1, "version": 1,
         "accepted": True, "repairs": 0, "seconds": 42.0,
         "memory_tool_calls": 3, "eligible_traces": 0},
        {"type": "ATTEMPT_DONE", "swarm": "warm", "attempt": 2,
         "tests_passed": 33, "turns_used": 7, "attempt_seconds": 240.0,
         "attempt_prompt_tokens": 90_000, "attempt_completion_tokens": 3_000,
         "skill_version": 1, "ended_cleanly": True},
        {"type": "FILE_DONE", "swarm": "warm", "success": True, "attempts": 2},
        {"type": "ATTEMPT_DONE", "swarm": "cold", "attempt": 1,
         "tests_passed": 8, "turns_used": 11, "attempt_seconds": 300.0,
         "attempt_prompt_tokens": 100_000, "attempt_completion_tokens": 3_500,
         "skill_version": None, "ended_cleanly": True},
        {"type": "FILE_DONE", "swarm": "cold", "success": False, "attempts": 1},
    ]


def _collect(**over):
    kw = dict(run_id="swarm-1", gpu="H200", model="mistral", commit="abc1234",
              skill_version=1, skill_approx_tokens=520, skill_dir_sha="deadbeef",
              arms_identical=True, known_differences=[],
              distil_usage={"warm": {"prompt_tokens": 30_000,
                                     "completion_tokens": 2_000}})
    kw.update(over)
    return m.collect(_events(), **kw)


def test_attempt_and_distillation_tokens_never_merge() -> None:
    warm = _collect().arms["warm"]
    assert warm.attempt_prompt_tokens == 210_000
    assert warm.attempt_completion_tokens == 7_000
    assert warm.distil_prompt_tokens == 30_000
    assert warm.distil_completion_tokens == 2_000
    # The distiller's tokens must not have leaked into the attempt totals.
    assert warm.attempt_prompt_tokens != (210_000 + 30_000)


def test_cold_has_no_distillation_cost() -> None:
    """Cold never distils: no skill to improve, no graph to read."""
    cold = _collect().arms["cold"]
    assert cold.distil_prompt_tokens == 0
    assert cold.distil_seconds == 0.0
    assert cold.distillations == 0


def test_per_attempt_rows_record_the_skill_version_used() -> None:
    """Distillation changes the skill BETWEEN attempts, so a run-level
    version number would attribute attempt 1's result to the version that
    only existed after it."""
    warm = _collect().arms["warm"]
    assert [a["skill_version"] for a in warm.per_attempt] == [0, 1]
    assert [a["tests_passed"] for a in warm.per_attempt] == [12, 33]


def test_convergence_and_totals() -> None:
    result = _collect()
    assert result.arms["warm"].converged is True
    assert result.arms["cold"].converged is False
    assert result.arms["warm"].attempts == 2
    assert result.arms["warm"].turns == 16
    assert result.arms["warm"].steps_ingested == 9
    assert result.arms["warm"].skill_versions == [1]


def test_a_run_with_arm_differences_does_not_count() -> None:
    """A debugging run must never be readable later as evidence."""
    good = _collect()
    assert good.counts_toward_clearly_working is True
    bad = _collect(arms_identical=False, known_differences=["tools"])
    assert bad.counts_toward_clearly_working is False
    bad2 = _collect(arms_identical=True, known_differences=["hook_files"])
    assert bad2.counts_toward_clearly_working is False


def test_the_table_marks_which_runs_count(tmp_path) -> None:
    table = tmp_path / "cross-run.md"
    m.append_to_table(_collect(), path=table)
    m.append_to_table(_collect(run_id="swarm-2", arms_identical=False,
                               known_differences=["tools"]), path=table)
    text = table.read_text()
    assert text.count("| swarm-1 |") == 2, "one row per arm"
    assert "yes |" in text
    assert "NO (debug) |" in text
    # The header is written once, not per run.
    assert text.count("| run | gpu |") == 1


def test_metrics_are_written_beside_the_event_log(tmp_path) -> None:
    path = m.write(_collect(), runs_dir=tmp_path)
    payload = json.loads(path.read_text())
    assert payload["counts_toward_clearly_working"] is True
    assert payload["arms"]["warm"]["distil_prompt_tokens"] == 30_000
    assert payload["skill_dir_sha"] == "deadbeef"


def test_collect_is_pure_and_rerunnable() -> None:
    """Derived from the event log only, so a metrics bug cannot corrupt
    the record it describes -- rerun it and get the same numbers."""
    first, second = _collect(), _collect()
    assert first.arms["warm"].per_attempt == second.arms["warm"].per_attempt
    assert first.arms["warm"].attempt_seconds == second.arms["warm"].attempt_seconds


def test_summary_states_whether_the_run_counts() -> None:
    assert "counts toward clearly-working: YES" in m.summarise(_collect())
    bad = m.summarise(_collect(arms_identical=False,
                               known_differences=["tools"]))
    assert "counts toward clearly-working: NO" in bad
    assert "debugging run only" in bad


def test_provision_starts_a_proxy_for_every_measured_thing() -> None:
    """Three counting proxies, not two.

    Vibe surfaces no per-call usage, so each number that must be reported
    separately needs its own endpoint. A missing 8821/8822 is caught by
    the runner's preflight ("not answering"); a missing 8823 is NOT -- it
    reports zero distillation tokens, which reads as a distiller that cost
    nothing rather than one that was never measured. Hence the check here,
    against the script that is supposed to start it.
    """
    from pathlib import Path

    script = (Path(__file__).resolve().parent.parent
              / "swarm" / "provision.sh").read_text()
    for port, what in ((8821, "warm attempts"), (8822, "cold attempts"),
                       (8823, "the distillation turn")):
        assert str(port) in script, (
            f"provision.sh starts no counting proxy on {port} ({what})")
    # Restarting a proxy loses the cumulative baseline the runner
    # subtracts from, so an already-running one must be left alone.
    assert "already listening" in script
    assert "/usage" in script, "the script must verify each proxy answers"


def test_an_external_writers_tokens_are_not_reported_as_zero() -> None:
    """An OpenAI call does not pass through the pod's counting proxy, so
    the runner must read the writer's own counters. Reporting zero would
    say the distillation was free rather than unmeasured."""
    from orchestrator.writers import ExternalWriter

    writer = ExternalWriter("gpt-5.5-2026-04-23", api_key="test-key")
    assert writer.usage == {"prompt_tokens": 0, "completion_tokens": 0}
    writer.usage["prompt_tokens"] = 41_000
    writer.usage["completion_tokens"] = 2_100
    result = _collect(distil_usage={"warm": dict(writer.usage)})
    assert result.arms["warm"].distil_prompt_tokens == 41_000
    assert result.arms["warm"].distil_completion_tokens == 2_100


def test_the_runner_reads_the_writers_own_usage() -> None:
    """Pinned by source, because getting this wrong is silent: the numbers
    are plausible, just always zero."""
    import inspect

    import swarm.run as runner
    src = inspect.getsource(runner.main_async)
    assert 'getattr(writer, "usage", None)' in src
    assert "proxy_usage(host, args.distill_proxy)" in src, (
        "the agent writer's tokens still have to come from the proxy")


def test_after_clock_graph_work_is_bounded() -> None:
    """Entity extraction is an OpenAI round trip per message, running
    after the measured window. One run finished its agent work at t=214
    and was still blocked in SSL inside this block 18 minutes later,
    stalling an A/B sweep. It cannot change a result, so it must not be
    able to hold a run open."""
    import inspect

    import swarm.run as runner
    src = inspect.getsource(runner.main_async)
    assert "ENTITY_TIMEOUT_S" in src
    assert src.count("asyncio.wait_for") >= 2, (
        "both extract_entities_from_session and link_step_entities must be "
        "bounded; either one can block indefinitely")
    assert "asyncio.TimeoutError" in src
    assert runner.ENTITY_TIMEOUT_S <= 600


def test_progress_is_measurable_when_the_package_will_not_import() -> None:
    """`tests_passed` cannot separate progress from damage.

    Every one of the fixture's 445 tests imports the package, so the score
    is 0 both when the migration has not started and when the agent has
    broken the file. Measured over 77 graded attempts: 70% scored exactly
    0. A skill effect is invisible through that.
    """
    from orchestrator import surfaces

    broken = {"pkg/models.py": b"class Config:\n    extra = .allow\n"}
    assert surfaces.count(broken) > 0, (
        "a tree that does not even parse must still yield a count -- that "
        "is the whole point")

    started = {"pkg/a.py": b"class Config:\n    orm_mode = True\n",
               "pkg/b.py": b"@validator('x')\ndef v(cls, y): return y\n"}
    partly = {"pkg/a.py": b"model_config = ConfigDict(from_attributes=True)\n",
              "pkg/b.py": b"@validator('x')\ndef v(cls, y): return y\n"}
    done = {"pkg/a.py": b"model_config = ConfigDict(from_attributes=True)\n",
            "pkg/b.py": b"@field_validator('x')\ndef v(cls, y): return y\n"}
    assert surfaces.count(started) > surfaces.count(partly) > surfaces.count(done)
    assert surfaces.count(done) == 0


def test_the_counter_moves_on_the_real_fixture_and_bottoms_out() -> None:
    """Pinned against both ends of the actual migration, because a
    progress measure that does not move is worse than none."""
    import pathlib

    from orchestrator import surfaces

    def load(root):
        root = pathlib.Path(root)
        return {str(p.relative_to(root)): p.read_bytes()
                for p in root.rglob("*.py")}

    pre = surfaces.count(load("fixtures/oapi/openapi_python_client"))
    post = surfaces.count(load("fixtures/oapi/reference_v2/openapi_python_client"))
    assert pre >= 60, f"pre-migration source should be rich in v1: {pre}"
    # NOT zero: the human's own answer keeps two `response.json()` calls in
    # generated-code strings and one unrelated `class Config`. The floor is
    # measured, not assumed, so that 3 is read as "done" and not "almost".
    assert post <= 5, f"the reference answer should bottom out: {post}"
    assert pre > post * 10


def test_the_fixture_scorer_and_the_harness_share_one_definition() -> None:
    """Two copies would drift, and then "surfaces in this fixture" and
    "surfaces left in this tree" become different questions with the same
    name."""
    from pathlib import Path

    src = (Path(__file__).resolve().parent.parent
           / "scripts" / "make_fixture.py").read_text()
    assert "from orchestrator.surfaces import SURFACES" in src
    assert "SURFACES = {" not in src, "make_fixture must not keep its own table"


def test_per_attempt_rows_carry_the_progress_count() -> None:
    events = _events()
    for e in events:
        if e["type"] == "ATTEMPT_DONE":
            e["v1_remaining"] = 40 if e["attempt"] == 1 else 12
    result = m.collect(events, run_id="r", gpu="g", model="m", commit="c",
                       skill_version=1, skill_approx_tokens=10,
                       skill_dir_sha="d", arms_identical=True,
                       known_differences=[], distil_usage={})
    assert [a["v1_remaining"] for a in result.arms["warm"].per_attempt] == [40, 12]


def test_the_progress_count_is_scoped_to_the_package() -> None:
    """Unscoped, the count is dominated by files the agent never edits.

    Measured on the oapi fixture: the whole shipped tree scores 93 and the
    package alone scores 64. The extra 29 are `end_to_end_tests/` and
    `integration-tests/` -- generated client code that no attempt touches,
    so it is a constant that never moves and swamps the signal. First run
    with the metric recorded warm at 35, 35, 33, 33 across four attempts
    that took the suite from 0 to 443.
    """
    import inspect

    import swarm.run as runner
    from orchestrator import vibe_agent

    src = inspect.getsource(vibe_agent.migrate_codebase)
    assert "within=package_path" in src
    assert "package_path" in inspect.signature(
        runner.agent_worker).parameters, (
        "the runner must be able to say which directory the migration is in")
    assert 'load_manifest().get("package_path")' in inspect.getsource(
        runner.main_async), "and it must come from the manifest, not a guess"
