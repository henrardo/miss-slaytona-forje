"""The distillation turn: what it may write, and what it must refuse.

The skill is loaded into every subsequent warm attempt, so a bad version is
not a wasted turn -- it poisons the arm for the rest of the run. These pin
the properties that make that safe: an invalid proposal never becomes live,
the validator's own words go back to the model, a distiller that dies costs
a version and not a run, and the prompt contains no migration knowledge.
"""
from __future__ import annotations

import asyncio
import shutil

import pytest

from orchestrator import distill, skills


@pytest.fixture
def sandbox(tmp_path, monkeypatch):
    """A copy of the real skill package, so tests cannot damage the live one."""
    root = tmp_path / "skills"
    shutil.copytree(skills.SKILLS_DIR, root)
    monkeypatch.setattr(skills, "SKILLS_DIR", root)
    monkeypatch.setattr(skills, "VALIDATOR", root / "_aip" / "validate.py")
    return root


def _next(offset: int = 1) -> int:
    """The version a proposal must carry. RELATIVE, because the live skill
    advances every real run -- a hard-coded 1 passes until the agent
    distils for the first time and then fails everywhere at once."""
    return skills.current().version + offset


def _skill(version: int, *, purpose: str = "Migrate a codebase.") -> str:
    return f'''---
name: pydantic-v2-migration
description: A distilled procedure, written by the agent from its own graded attempts.
metadata:
  aip:
    spec: "https://arxiv.org/abs/2606.04781"
    schemaId: "https://raw.githubusercontent.com/zach-blumenfeld/aip/v0.3a3/assets/aip-schemas/procedure.schema.json"
    version: {version}
    derived_from_traces: []
---

```yaml
purpose: >
  {purpose}
trigger_when:
  - Asked to migrate to Pydantic v2
steps:
  - name: run-the-suite
    description: Run the suite and read the first error.
```
'''


class FakeWorkspace:
    """A distiller's environment, in memory.

    `writes` is what the model chooses to leave in its output file, one
    entry per turn -- so a test can script "invalid, invalid, valid" and
    check the repair loop.
    """

    def __init__(self, writes: list[str], *, stream: list[dict] | None = None,
                 explode: bool = False) -> None:
        self.writes = list(writes)
        self.stream = stream or []
        self.explode = explode
        self.prompts: list[str] = []
        self.cleared = 0
        self._file = ""

    def distill_skill_path(self) -> str:
        return "/home/agent-warm-0/distill/SKILL.md"

    def clear_distilled(self) -> None:
        """Mirrors the real one: the output file must NOT exist.

        Vibe's write_file refuses to overwrite ("Use edit to modify it"),
        so a distiller whose output path already holds a file writes
        nothing at all -- which is how every distillation failed in the
        first local rehearsal. The fake starts empty for the same reason.
        """
        self.cleared += 1
        self._file = ""

    def read_distilled(self) -> str:
        return self._file

    def stream_entries(self, stdout: str) -> list[dict]:
        return self.stream

    async def run_distill(self, prompt: str, *, timeout_s: float,
                          resume: bool = False):
        self.prompts.append(prompt)
        if self.explode:
            raise RuntimeError("ssh died")
        self._file = self.writes.pop(0) if self.writes else ""
        return 0, ""


class FakeMem:
    def __init__(self, eligible: list[dict] | None = None,
                 explode: bool = False) -> None:
        self._eligible = eligible or []
        self.explode = explode

    async def eligible_traces(self, *, model: str, schema: float = 2.0):
        if self.explode:
            raise RuntimeError("Aura is down")
        return self._eligible


async def _run(ws, mem=None, **kw):
    return await distill.distill(
        workspace=ws, mem=mem or FakeMem(), model="m", attempt=1,
        tests_passed=0, suite_passed=False, **kw)


@pytest.mark.asyncio
async def test_a_valid_proposal_becomes_the_next_version(sandbox) -> None:
    before = skills.current().version
    ws = FakeWorkspace([_skill(_next())])
    result = await _run(ws)
    assert result.accepted is not None, result.rejection
    assert result.version == _next() - 1
    assert skills.current().version == before + 1
    assert result.repairs == 0


@pytest.mark.asyncio
async def test_an_invalid_proposal_is_repaired_then_accepted(sandbox) -> None:
    """Two repair turns are allowed; the validator's own diagnostics go
    back each time."""
    expected = _next()
    ws = FakeWorkspace(["not a skill at all", _skill(expected)])
    result = await _run(ws)
    assert result.accepted is not None, result.rejection
    assert result.repairs == 1
    assert len(ws.prompts) == 2
    # The repair prompt must carry the validator's output, not a paraphrase.
    assert "rejected and has NOT been saved" in ws.prompts[1]
    assert f"version` must be exactly {expected}" in ws.prompts[1]


@pytest.mark.asyncio
async def test_three_bad_proposals_keep_the_previous_version(sandbox) -> None:
    """After the repair budget, the live skill is untouched and the
    rejection is recorded rather than swallowed."""
    before = skills.current()
    ws = FakeWorkspace(["garbage", "still garbage", "garbage again"])
    result = await _run(ws)
    assert result.accepted is None
    assert result.rejection is not None
    assert result.repairs == 2
    assert len(ws.prompts) == 3, "the repair budget is 2 turns after the first"
    assert skills.current().text == before.text
    assert f"kept v{skills.current().version}" in result.note


@pytest.mark.asyncio
async def test_a_distiller_that_writes_nothing_is_a_rejection(sandbox) -> None:
    """An empty file is not a valid skill, and it is a different failure
    from an invalid one -- the model never answered."""
    ws = FakeWorkspace(["", "", ""])
    result = await _run(ws)
    assert result.accepted is None
    assert result.rejection.reason == "no_output"


@pytest.mark.asyncio
async def test_a_dead_distiller_costs_a_version_not_a_run(sandbox) -> None:
    """It runs after the attempt is graded and the trace closed."""
    before = skills.current()
    result = await _run(FakeWorkspace([], explode=True))
    assert result.accepted is None
    assert "did not run" in result.note
    assert skills.current().text == before.text


@pytest.mark.asyncio
async def test_an_unreachable_graph_still_lets_distillation_proceed(sandbox) -> None:
    """The model can write a better procedure from the attempt it just
    lived through, even if the graph is down."""
    result = await _run(FakeWorkspace([_skill(_next())]), mem=FakeMem(explode=True))
    assert result.accepted is not None
    assert result.eligible_traces == 0


@pytest.mark.asyncio
async def test_an_oversized_proposal_is_rejected(sandbox) -> None:
    """The skill is prompt prefix on every attempt, so a distiller that
    pads is charging the arm whose token count is the headline number.

    Sized off the cap rather than hard-coded: this test silently stopped
    testing anything when the cap moved from 2,000 to 13,000, because its
    8,000-token padding was suddenly legal.
    """
    over = skills.DEFAULT_MAX_TOKENS + 1000          # tokens
    huge = _skill(_next(), purpose="padding " * (over * 4 // len("padding ")))
    ws = FakeWorkspace([huge, huge, huge])
    result = await _run(ws)
    assert result.accepted is None
    assert result.rejection.reason == "too_large"


@pytest.mark.asyncio
async def test_memory_tool_calls_are_counted(sandbox) -> None:
    """"The distiller never queried the graph" is a finding the mission
    asks for by name, so it has to be countable."""
    stream = [
        {"type": "reasoning", "turnId": "t", "text": "what did I try before"},
        {"type": "effect", "turnId": "t", "title": "neo4j-agent-memory_search_steps",
         "detail": {"toolName": "neo4j-agent-memory_search_steps",
                    "input": {"query": "BaseSettings"}},
         "state": {"status": "completed", "outputText": "3 hits"}},
        {"type": "reasoning", "turnId": "t", "text": "now write it"},
        {"type": "effect", "turnId": "t", "title": "write_file",
         "detail": {"toolName": "write_file", "input": {"path": "SKILL.md"}},
         "state": {"status": "completed", "outputText": "ok"}},
    ]
    result = await _run(FakeWorkspace([_skill(_next())], stream=stream))
    assert result.memory_tool_calls == 1
    assert result.queries and "search_steps" in result.queries[0]


def test_the_prompt_contains_no_migration_answer() -> None:
    """The skill must come only from the agent's own distillation. If the
    prompt named the fix, warm's advantage would be the prompt's."""
    prompt = distill.build_prompt(
        skills.current(), attempt=2, tests_passed=12, suite_passed=False,
        error="E   ImportError: cannot import name 'BaseSettings'",
        eligible=[], out_path="/tmp/SKILL.md")
    # EXCLUDING the <current_skill> block. From v1 onward that block is the
    # agent's OWN distilled procedure, quoted back so it can improve it --
    # so it contains the migration answer by design, and including it here
    # would make this test fail on success. What must stay clean is the
    # part the HARNESS writes.
    import re as _re
    harness_written = _re.sub(r"<current_skill>.*?</current_skill>", "",
                              prompt, flags=_re.DOTALL)
    assert "<current_skill>" in prompt, "the current skill is no longer quoted"
    lowered = harness_written.lower()
    for leak in ("pydantic_settings", "field_validator", "model_validator",
                 "model_config", "email_validator", "configdict",
                 "basesettings has been moved"):
        assert leak not in lowered, f"the distillation prompt contains {leak!r}"
    # The two gaming patterns ARE named: the grader rejects them and the
    # migrating agent is told so already, so this adds nothing it lacks.
    assert "pydantic.v1" in prompt


def test_the_prompt_states_the_format_the_validator_enforces() -> None:
    """A distiller that does not know the version must advance will fail
    every turn of its repair budget on the same error."""
    live = skills.current()
    prompt = distill.build_prompt(
        live, attempt=1, tests_passed=0, suite_passed=False,
        error=None, eligible=[], out_path="/tmp/SKILL.md")
    assert f"must be exactly {live.version + 1}" in prompt
    assert "one fenced yaml block" in prompt.lower()
    assert str(skills.DEFAULT_MAX_TOKENS) in prompt


@pytest.mark.asyncio
async def test_concurrent_proposals_do_not_collide(sandbox) -> None:
    """Two warm agents finishing at once both read v0 and both write v1.
    Without the lock one version silently overwrites the other and the
    graph records two skills with the same number."""
    body = _skill(_next())   # computed ONCE: both threads race the same N

    def propose(_n: int):
        return skills.propose(body, derived_from=[])

    results = await asyncio.gather(
        asyncio.to_thread(propose, 1), asyncio.to_thread(propose, 2))
    accepted = [r for r in results if isinstance(r, skills.SkillVersion)]
    rejected = [r for r in results if isinstance(r, skills.Rejection)]
    assert len(accepted) == 1, "both proposals became the same version"
    assert len(rejected) == 1
    assert rejected[0].reason == "wrong_version"
    assert skills.current().version == accepted[0].version


@pytest.mark.asyncio
async def test_the_output_file_is_cleared_before_every_turn(sandbox) -> None:
    """Vibe's write_file will not overwrite an existing file, so a turn
    whose output path is already occupied silently produces nothing. The
    first local rehearsal failed every distillation this way."""
    ws = FakeWorkspace(["garbage", _skill(_next())])
    result = await _run(ws)
    assert result.accepted is not None, result.rejection
    assert ws.cleared == 2, (
        f"cleared {ws.cleared} time(s) for {len(ws.prompts)} turn(s); the "
        f"repair turn would collide with the rejected turn's file")


def test_the_real_workspace_has_every_method_the_distiller_calls() -> None:
    """Run 1 lost its distillation to
    `AttributeError: 'AgentWorkspace' object has no attribute
    'seed_distillation'` -- a method renamed to `clear_distilled` while
    swarm/run.py's closure still called the old name.

    The rehearsal missed it because it calls `distill()` directly rather
    than through run.py's closure, and FakeWorkspace was updated with the
    rename. So the contract is asserted against the REAL class here.
    """
    import inspect

    from swarm.agent_workspace import AgentWorkspace

    for method in ("distill_skill_path", "clear_distilled", "read_distilled",
                   "run_distill", "stream_entries", "enable_distillation",
                   "install_skill", "loaded_skill_text", "has_skills_dir",
                   "setup_fingerprint"):
        assert hasattr(AgentWorkspace, method), (
            f"AgentWorkspace has no {method!r}; the distillation turn or the "
            f"run's checks would die at runtime, after the attempt")

    # And nothing in the runner may call a workspace method that is gone.
    runner = inspect.getsource(
        __import__("swarm.run", fromlist=["run"]))
    assert "seed_distillation" not in runner


def test_the_prompt_warns_about_the_yaml_colon_trap() -> None:
    """Run 4 lost all three distillation turns to one YAML rule.

    The model wrote `- Leaving type: ignore comments in the codebase`,
    which YAML parses as a MAPPING, so the schema rejected it with
    "is not of type 'string'". The validator's diagnostic went back on
    both repair turns and the model made the same mistake each time, so
    the diagnostic alone was not enough -- the prompt now states the rule
    up front and carries a minimal worked example.
    """
    prompt = distill.build_prompt(
        skills.current(), attempt=1, tests_passed=0, suite_passed=False,
        error=None, eligible=[], out_path="/tmp/SKILL.md")
    assert "EVERY LIST ITEM MUST BE A PLAIN STRING" in prompt
    assert "a MAPPING" in prompt
    # Both real failures, as counter-examples: the unquoted colon (run 4)
    # and the partially-quoted item (run 5).
    assert "text outside" in prompt
    # The exact line the model has now produced twice (runs 5 and 8).
    assert "THE RULE: an item is either entirely inside ONE pair" in prompt
    assert "appears in the output" in prompt
    # A worked example, not just a rule.
    assert "Here is a minimal valid example" in prompt
    assert "a-kebab-case-step-name" in prompt

    rejection = skills.Rejection(
        reason="invalid_schema",
        detail="{'Leaving type': 'ignore'} is not of type 'string'",
        proposal="")
    repair = distill.repair_prompt(rejection, "/tmp/SKILL.md", 2)
    assert "unquoted colon" in repair
    assert "expected <block end>" in repair, (
        "the repair prompt must also decode the parse error the model hit "
        "when it quoted only part of a list item")


# ---- who writes the skill --------------------------------------------------

def test_the_external_writer_is_handed_the_evidence() -> None:
    """An API call has no MCP tools, so it cannot query the graph. The
    traces must travel in its prompt -- and the prompt must not tell a
    tool-less writer to use tools it does not have."""
    steps = [{"trace": "t1", "suite_passed": True,
              "thought": "BaseSettings moved, so the import must change",
              "action": "edit(config.py)", "observation": "ok"}]
    external = distill.build_prompt(
        skills.current(), attempt=1, tests_passed=0, suite_passed=False,
        error=None, eligible=[{"id": "t1", "steps": 1, "metrics": {}}],
        out_path="X", steps=steps, has_graph_tools=False)
    assert "BaseSettings moved" in external
    assert "You have\n    memory tools" not in external

    agent = distill.build_prompt(
        skills.current(), attempt=1, tests_passed=0, suite_passed=False,
        error=None, eligible=[{"id": "t1", "steps": 1, "metrics": {}}],
        out_path="X", steps=steps, has_graph_tools=True)
    assert "memory tools" in agent
    # The agent chooses what to look at; handing it the steps would remove
    # the behaviour the run is measuring.
    assert "BaseSettings moved" not in agent


def test_an_outer_fence_is_stripped_but_the_bodys_own_fence_survives() -> None:
    """A SKILL.md contains a ```yaml block, so a model told 'reply with
    the file' usually wraps the whole thing in a second fence. Losing a
    repair turn to packaging would be a waste of the budget."""
    from orchestrator.writers import strip_fence

    inner = "---\nname: x\n---\n\n```yaml\npurpose: y\n```"
    assert strip_fence(f"```markdown\n{inner}\n```") == inner
    assert strip_fence(inner) == inner
    assert strip_fence(f"```\n{inner}\n```").endswith("```")


def test_the_external_writer_refuses_to_start_without_a_key() -> None:
    """Better to fail at construction than after an attempt, where it
    would silently keep the previous skill version."""
    import pytest as _pytest

    from orchestrator.writers import ExternalWriter
    with _pytest.raises(RuntimeError, match="OPENAI_API_KEY"):
        ExternalWriter("gpt-5", api_key="")


def test_the_writer_is_told_how_much_headroom_is_left(tmp_path) -> None:
    """"Stay under 2000 tokens" is not actionable without knowing where
    you are.

    The skill grew 1647 -> 1609 -> 1754 -> 1816 -> 1839 over runs 3 to 11
    against a 2000 cap. A writer that keeps appending hits the cap, the
    proposal is rejected outright, the previous version stays live, and
    the loop silently stops improving -- a distiller that looks like it is
    working and is not.
    """
    current = skills.current()
    prompt = distill.build_prompt(
        current=current, attempt=4, tests_passed=30, suite_passed=False,
        error="E   ImportError: cannot import name 'validator'",
        eligible=[], out_path="/tmp/SKILL.md", has_graph_tools=True)
    assert str(current.approx_tokens) in prompt, (
        "the writer is not told the current size")
    headroom = skills.DEFAULT_MAX_TOKENS - current.approx_tokens
    assert str(max(headroom, 0)) in prompt, (
        "the writer is not told the remaining headroom")
    # And what to do about it, since appending is what a model does by
    # default when asked to improve a document.
    low = prompt.lower()
    assert "delete steps" in low and "merge steps" in low


def test_distillation_only_learns_from_this_fixtures_traces() -> None:
    """A booklet for codebase B must not be distilled from codebase A.

    Measured when the second fixture went live: its very FIRST
    distillation reported 25 eligible traces, before that fixture had
    produced a single one. All 25 belonged to the previous fixture, and
    the skill it wrote said so in its own comments -- "Attempt 3 regressed
    on a different repository". That is the seeding the whole experiment
    exists to rule out, arriving through the graph instead of by hand.
    """
    import inspect

    from orchestrator import memory as memory_mod

    src = inspect.getsource(distill.distill)
    assert "fixture=FIXTURE_DIR.name" in src, (
        "the distiller must scope eligible traces to the active fixture")

    sig = inspect.signature(memory_mod.ScopedMemory.eligible_traces)
    assert "fixture" in sig.parameters
    # Default None keeps pre-existing traces reachable on purpose rather
    # than by accident -- they predate the property.
    assert sig.parameters["fixture"].default is None
    query_src = inspect.getsource(memory_mod.ScopedMemory.eligible_traces)
    assert "t.prov_fixture = $fixture" in query_src


def test_every_trace_records_which_codebase_it_came_from() -> None:
    """The filter above is only as good as the stamp."""
    import inspect

    import swarm.run as runner

    src = inspect.getsource(runner.main_async)
    assert '"prov_fixture": FIXTURE_DIR.name' in src
