"""Getting a skill into the model's context, and proving it got there.

Three separate things have to be true, and each can succeed while the next
fails silently:

  1. the file is written where Vibe looks,
  2. Vibe parses it and offers it,
  3. Vibe puts its text in the conversation.

This project has already paid for the equivalent gap once: run 9's memory
server was configured, running and answering, and the model was handed zero
memory tools -- which in the summary looked exactly like a model that chose
not to use memory. A skill that never loads looks exactly like a model that
ignored its own procedure, and the two have opposite fixes.

Nothing here needs a pod: the host is faked and every command it would run
over SSH is answered from a dict.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from orchestrator import skills, vibe_agent
from swarm.agent_workspace import AgentWorkspace, SwarmHost, _body_sha


class FakeHost(SwarmHost):
    """A pod's filesystem, in a dict.

    It answers the three commands `install_skill` actually runs -- the
    recursive `sha256sum` read-back, `test -x`, and `cat` -- from what was
    written to it, so the verification path is exercised rather than
    stubbed. `drop_on_readback` and `corrupt_on_readback` simulate the two
    ways a transfer goes wrong quietly.
    """

    def __init__(self) -> None:
        super().__init__(host="fake", port=22, identity=Path("/dev/null"))
        self.commands: list[str] = []
        self.files: dict[str, bytes] = {}
        self.modes: dict[str, str] = {}
        self.answers: dict[str, str] = {}
        self.drop_on_readback: set[str] = set()
        self.corrupt_on_readback: set[str] = set()
        self.executable = True

    def _answer(self, command: str):
        self.commands.append(command)
        for needle, reply in self.answers.items():
            if needle in command:
                return _Completed(reply)
        if "rm -rf" in command:
            root = command.split("rm -rf ", 1)[1].split()[0]
            for path in [p for p in self.files if p.startswith(root)]:
                del self.files[path]
            return _Completed("")
        if "sha256sum" in command:
            return _Completed(self._sha_listing(command))
        if command.startswith("test -x "):
            return _Completed("yes" if self.executable else "no")
        if command.startswith("cat "):
            return _Completed(self.files.get(command[4:], b"").decode())
        return _Completed("")

    def _sha_listing(self, command: str) -> str:
        root = command.split("cd ", 1)[1].split(" &&")[0].strip("'\"")
        lines = []
        for path, content in sorted(self.files.items()):
            if not path.startswith(root + "/"):
                continue
            rel = path[len(root) + 1:]
            if rel in self.drop_on_readback:
                continue
            if rel in self.corrupt_on_readback:
                content = content + b"tampered"
            lines.append(f"{hashlib.sha256(content).hexdigest()}  ./{rel}")
        return "\n".join(lines)

    def run(self, command: str, **kw):
        return self._answer(command)

    def run_as(self, agent_user: str, command: str, **kw):
        return self._answer(command)

    def put(self, data: bytes, dst: str, *, mode: str = "600",
            owner: str | None = None) -> None:
        self.files[dst] = data
        self.modes[dst] = mode


class _Completed:
    def __init__(self, stdout: str) -> None:
        self.stdout, self.stderr, self.returncode = stdout, "", 0


class _WS(AgentWorkspace):
    """Forwards the fake host's knobs so tests read as one object."""

    def __getattr__(self, item):
        if item in ("drop_on_readback", "corrupt_on_readback", "modes"):
            return getattr(self.host, item)
        raise AttributeError(item)

    def __setattr__(self, key, value):
        if key == "executable":
            self.host.executable = value
            return
        super().__setattr__(key, value)


@pytest.fixture
def ws() -> AgentWorkspace:
    return _WS(host=FakeHost(), label="warm-0", model="m")


LIVE = skills.current()
PACKAGE = skills.package()


def test_the_whole_package_lands_where_vibe_looks(ws) -> None:
    """$VIBE_HOME/skills/<name>/, per Vibe's GLOBAL_SKILLS_DIR.

    Verified against mistral-vibe 2.25.4 by loading this exact SKILL.md
    through Vibe's own SkillManager: discovered, parsed, and returned by
    parse_skill_command("/pydantic-v2-migration ...").

    The whole DIRECTORY, not the one file: an AIP skill carries `source/`
    with the schema its own frontmatter references, and may carry
    `scripts/`, `references/` and `assets/`.
    """
    ws.install_skill(PACKAGE, name=skills.SKILL_NAME)
    root = f"/home/agent-warm-0/.vibe/skills/{skills.SKILL_NAME}"
    for rel, content in PACKAGE.items():
        assert ws.host.files[f"{root}/{rel}"] == content, f"{rel} did not land"
    assert len(PACKAGE) > 1, "the fixture stopped exercising the multi-file case"
    assert any("source/" in k for k in PACKAGE), (
        "source/ is required by the AIP validator and must travel with the skill")


def test_installing_removes_the_previous_version(ws) -> None:
    """Vibe lists every skill it finds. A stale version left beside the new
    one is offered to the agent as an alternative procedure, and a deleted
    file would otherwise live on forever."""
    ws.install_skill(PACKAGE, name=skills.SKILL_NAME)
    wipes = [c for c in ws.host.commands if "rm -rf" in c and "skills" in c]
    assert wipes, f"the skills directory was not cleared: {ws.host.commands}"


def test_install_fails_loudly_if_a_file_did_not_land(ws) -> None:
    """Verifying what was sent proves nothing about what arrived."""
    ws.drop_on_readback.add("source/procedure.schema.json")
    with pytest.raises(RuntimeError, match="not the skill that was sent"):
        ws.install_skill(PACKAGE, name=skills.SKILL_NAME)


def test_install_fails_if_a_file_arrived_corrupted(ws) -> None:
    ws.corrupt_on_readback.add("SKILL.md")
    with pytest.raises(RuntimeError, match="differing="):
        ws.install_skill(PACKAGE, name=skills.SKILL_NAME)


def test_scripts_are_installed_executable(ws) -> None:
    """An AIP step with `script:` is useless if the script cannot run, and
    the failure is quiet -- the model improvises around it."""
    pkg = dict(PACKAGE)
    pkg["scripts/check.py"] = b"print('hi')\n"
    ws.install_skill(pkg, name=skills.SKILL_NAME)
    root = f"/home/agent-warm-0/.vibe/skills/{skills.SKILL_NAME}"
    assert ws.modes[f"{root}/scripts/check.py"] == "700"
    assert ws.modes[f"{root}/SKILL.md"] == "600"


def test_install_fails_if_a_script_is_not_executable(ws) -> None:
    pkg = dict(PACKAGE)
    pkg["scripts/check.py"] = b"print('hi')\n"
    ws.executable = False
    with pytest.raises(RuntimeError, match="not executable"):
        ws.install_skill(pkg, name=skills.SKILL_NAME)


def test_install_returns_both_hashes(ws) -> None:
    """The directory hash identifies the version; the body hash is the only
    thing a transcript can be checked against, because the frontmatter never
    reaches the model."""
    got = ws.install_skill(PACKAGE, name=skills.SKILL_NAME)
    assert got["body"] == LIVE.body_sha
    assert got["dir"] == LIVE.dir_sha
    assert got["dir"] != got["body"] != LIVE.sha


def test_the_two_body_splits_agree() -> None:
    """swarm/ deliberately does not import from orchestrator/ -- that package
    is not on the swarm host -- so the frontmatter split exists twice. This
    is what stops the copies drifting into two different answers to the same
    question."""
    cases = [
        LIVE.text,
        "---\nname: x\ndescription: y\n---\n\nbody\n",
        "---\na: 1\n---\nbody with --- inside\nand more\n",
        "no frontmatter at all",
        "﻿---\nname: x\n---\nbody\n",
    ]
    for text in cases:
        assert _body_sha(text) == skills._sha(skills.body_of(text)), (
            f"the two body splits disagree on {text[:40]!r}")


def test_cold_has_no_skills_directory(ws) -> None:
    ws.host.answers["test -d"] = "no"
    assert ws.has_skills_dir() is False
    ws.host.answers["test -d"] = "yes"
    assert ws.has_skills_dir() is True


def test_a_loaded_skill_is_found_in_the_transcript(ws) -> None:
    """Vibe wraps the injected skill in <skill_content name="...">
    (core/tools/builtins/skill.py: skill_content_marker)."""
    body = skills.body_of(LIVE.text)
    ws._cache = {"tree": {}, "sessions": [[
        {"role": "user", "content": f"/{skills.SKILL_NAME} Please migrate"},
        {"role": "tool", "name": "skill",
         "content": f'<skill_content name="{skills.SKILL_NAME}">\n'
                    f'# Skill: {skills.SKILL_NAME}\n\n{body}\n</skill_content>'},
    ]]}
    loaded = ws.loaded_skill_text(skills.SKILL_NAME)
    assert loaded is not None
    assert body in loaded, "the loaded text is not the version on disk"


def test_no_skill_in_the_transcript_reads_as_not_loaded(ws) -> None:
    """The distinction that matters: "the agent ignored its procedure" and
    "the procedure never reached it" have opposite fixes."""
    ws._cache = {"tree": {}, "sessions": [[
        {"role": "user", "content": "Please migrate"},
        {"role": "assistant", "content": "ok"},
    ]]}
    assert ws.loaded_skill_text(skills.SKILL_NAME) is None


def test_warm_prompt_starts_with_the_skill_command() -> None:
    """Vibe only treats a prompt as a skill invocation when it STARTS with
    `/<name>` (SkillManager.parse_skill_command). One leading character
    decides whether the skill is loaded or is a stray token."""
    warm = vibe_agent._task_prompt(None, memory_enabled=True,
                                   skill_command=skills.SKILL_NAME)
    assert warm.startswith(f"/{skills.SKILL_NAME} ")
    # The task must survive intact: Vibe splits once on whitespace and passes
    # the remainder through as extra_instructions.
    assert "migrate this codebase" in warm.lower()


def test_cold_prompt_has_no_skill_command() -> None:
    """Cold gets no skill, so the prefix would be a stray token pointing at a
    skill it does not have."""
    cold = vibe_agent._task_prompt(None, memory_enabled=False)
    assert not cold.startswith("/")


# ---- session policy --------------------------------------------------------
#
# Both arms start a fresh session on every attempt. Two reasons, and the
# second is the one that makes it apply to COLD as well:
#
#   1. Vibe will not reload a skill into a conversation that already has it
#      ("already loaded earlier in this conversation. Reuse those
#      instructions."), so after distillation a resumed warm agent would work
#      from the superseded text while the run recorded the new version.
#   2. Fixing that for warm alone would leave warm restarting while cold
#      carried its history forward -- two differences between the arms
#      instead of one, and no way to attribute a result to either.

def test_no_attempt_ever_resumes() -> None:
    """Pinned by reading the source, because the alternative is a live run.

    `resume` is passed straight to `--continue`; anything that makes it true
    again reintroduces both problems above at once.
    """
    import inspect

    from orchestrator import vibe_agent as va
    source = inspect.getsource(va.migrate_codebase)
    assignments = [line.strip() for line in source.splitlines()
                   if line.strip().startswith("resume =")]
    assert assignments == ["resume = False"], (
        f"migrate_codebase assigns resume as {assignments}. Both arms must "
        f"start every attempt fresh: a resumed session refuses to reload a "
        f"changed skill, and resuming one arm only makes the arms differ in "
        f"two ways."
    )


def test_the_prompt_is_the_only_difference_between_the_arms() -> None:
    """...and only by the `/skill-name` prefix, on every attempt.

    Tested through `attempt_prompt`, which is what migrate_codebase calls,
    rather than through `_task_prompt` with arguments a test chose -- the
    old asymmetry was invisible exactly because the call site passed
    `memory_enabled=mem is not None` while any test comparing prompts
    passed the same value to both.

    Warm's prompt used to carry three extra numbered steps and a closing
    note about memory tools: a longer prompt, more instructions and more
    tokens before warm started, on top of the difference being measured.
    """
    feedbacks = [
        None,                                    # attempt 1: no feedback yet
        "E   ImportError: cannot import name 'BaseSettings'",
        "=== 12 passed, 21 failed ===\nE   ValidationError: ...",
        "x" * 20_000,                            # long enough to be trimmed
    ]
    for feedback in feedbacks:
        warm = vibe_agent.attempt_prompt(feedback, skills.SKILL_NAME)
        cold = vibe_agent.attempt_prompt(feedback, None)
        assert warm == f"/{skills.SKILL_NAME} " + cold, (
            f"the arms' prompts differ by more than the skill prefix when "
            f"the previous attempt's feedback is {str(feedback)[:40]!r}")
        if feedback:
            # The grader's verdict reaches BOTH arms, in the same place and
            # the same format. It is the only thing either arm carries from
            # its last attempt, since neither resumes a session.
            assert "The test suite still fails:" in cold


def test_neither_arm_is_told_about_memory_tools_during_an_attempt() -> None:
    """Warm has none during an attempt: the graph is written afterwards,
    from the transcript. Instructions for tools the agent does not have are
    tokens spent on a capability it cannot use, and they are warm-only."""
    for skill in (None, skills.SKILL_NAME):
        prompt = vibe_agent.attempt_prompt("boom", skill)
        assert "memory tools" not in prompt.lower()
        assert "other agents" not in prompt.lower()


# ---- which version the agent is actually on ------------------------------
#
# Three separate things claimed to know the answer and only one of them
# could: the local registry's "newest", the run's banner, and the directory
# on the pod. The first two were what got reported, the third is what the
# model read.


def test_the_workspace_records_the_version_it_installed(ws) -> None:
    ws.install_skill(PACKAGE, name=skills.SKILL_NAME, version=LIVE.version)
    assert ws.installed_skill_version == LIVE.version
    assert ws.installed_skill_sha == _body_sha(LIVE.text)


def test_a_failed_install_does_not_claim_a_version(ws) -> None:
    """Recording the version before verification would leave the run
    reporting a procedure the agent never received."""
    ws.install_skill(PACKAGE, name=skills.SKILL_NAME, version=3)
    ws.drop_on_readback.add("SKILL.md")
    with pytest.raises(RuntimeError):
        ws.install_skill(PACKAGE, name=skills.SKILL_NAME, version=4)
    assert ws.installed_skill_version == 3, (
        "a broken install must leave the last VERIFIED version recorded, "
        "not the one it was trying to put there")


def test_an_empty_package_is_refused_rather_than_uninstalling(ws) -> None:
    """install_skill recreates the tree, so an empty dict is not a no-op --
    it removes the skill and returns the hash of nothing. Warm would run
    with no procedure while the log still named a version.

    This is reachable: `propose` used to return a SkillVersion with no
    files at all.
    """
    ws.install_skill(PACKAGE, name=skills.SKILL_NAME, version=1)
    for bad in ({}, {"source/schema.json": b"{}"}):
        with pytest.raises(ValueError, match="SKILL.md"):
            ws.install_skill(bad, name=skills.SKILL_NAME, version=2)
    assert ws.installed_skill_version == 1
    body = ws.host.files[f"{ws.home}/.vibe/skills/{skills.SKILL_NAME}/SKILL.md"]
    assert body == PACKAGE["SKILL.md"], "the real skill is still installed"


def test_the_attempt_loop_reads_the_workspace_not_the_registry() -> None:
    """Pinned by source because the failure is silent and inverted.

    `skills.current()` answers "what is newest on the orchestrator's disk".
    Under --skill-version every attempt was logged as the newest version
    while running the pinned one; with distillation on, an attempt was
    credited to a version that had not reached the pod. The numbers look
    fine either way -- they are just filed under the wrong procedure.
    """
    import inspect

    src = inspect.getsource(vibe_agent.migrate_codebase)
    assert 'getattr(workspace, "installed_skill_version", None)' in src
    assert "_skills.current(skill_name).version" not in src, (
        "the registry pointer is not what the model read")


def test_an_accepted_version_is_installed_before_the_next_attempt() -> None:
    """The self-improvement loop was open at its last inch.

    `propose` writes the new version to the orchestrator's disk and moves
    the live pointer, but the agent reads $VIBE_HOME/skills on the pod,
    which was last written at run setup. So attempt N+1 re-read the SAME
    procedure -- the skill could not improve WITHIN a run, which is exactly
    what a task that cannot be one-shotted is meant to measure.
    """
    import inspect

    import swarm.run as runner

    src = inspect.getsource(runner.main_async)
    assert "if outcome.accepted is not None:" in src
    assert "install_skill(outcome.accepted.files" in src
    assert "version=outcome.accepted.version" in src


def test_a_proposed_version_carries_a_complete_installable_package() -> None:
    """An accepted SkillVersion has to be shippable. `propose` returned one
    with `files` empty, so the caller held a version it could not install
    and `dir_sha` fell back to SKILL.md alone."""
    import inspect

    src = inspect.getsource(skills._propose_locked)
    assert "files=package(skill_name)" in src
    # And the same object shape as every other producer in the module.
    for producer in (skills.current(), skills.archived(0)):
        assert "SKILL.md" in producer.files
        assert producer.dir_sha == skills.dir_sha(producer.files)


def test_a_loaded_skill_can_be_identified_by_version() -> None:
    """The checklist has to name what the agent read, not what the run
    started on. Once distillation worked those diverged by design: run 10
    started on v5 and its attempts loaded v5, v6, v7."""
    # Whatever versions this lineage actually HAS. Using the live
    # version's number assumed it was archived here, which stopped being
    # true the moment a second fixture advanced the shared live file --
    # the default lineage stops at v13 and live is now v21.
    available = sorted(int(p.name[1:4])
                       for p in skills.versions_dir().glob("v*.md"))
    assert available, "no archived versions to identify against"
    for version in (available[0], available[-1]):
        body = skills.body_of(skills.archived(version).text)
        assert skills.identify(body) == version
    assert skills.identify("no skill here at all") is None
    assert skills.identify("") is None


def test_the_checklist_compares_against_the_attempts_own_version() -> None:
    """Pinned by source. Comparing against the run's starting version
    printed 'skill v5 reached 0/1 warm agent(s)' for a run whose loop had
    just worked for the first time -- a false negative in the one check
    that exists to catch a skill never reaching the model."""
    import inspect

    import swarm.run as runner

    src = inspect.getsource(runner.main_async)
    assert "skills.identify(loaded)" in src
    assert "last_version" in src
    assert "expected_body = skills.body_of(live_skill.text)" not in src, (
        "the run's starting version is the wrong baseline once the skill "
        "can advance mid-run")


# ---- keeping the best verified tree --------------------------------------


def test_the_grader_never_sees_the_checkpoint_history(ws) -> None:
    """`.git` is harness bookkeeping. Uploaded into the grading sandbox it
    would be megabytes per attempt and could shadow the real tree."""
    import inspect

    from swarm.agent_workspace import AgentWorkspace

    src = inspect.getsource(AgentWorkspace.tree)
    assert '".git"' in src


def test_a_restore_also_removes_untracked_files() -> None:
    """`reset --hard` alone keeps files the attempt ADDED.

    That is the failure this whole mechanism exists to undo: a broken
    module dropped into the package is untracked, survives the reset, and
    the same ImportError greets the next attempt -- a restore that
    restores nothing.
    """
    import inspect

    from swarm.agent_workspace import AgentWorkspace

    src = inspect.getsource(AgentWorkspace.restore_best)
    # Built through _git() now, so assert on the arguments rather than on
    # one rendered command string.
    assert "'reset', '-q', '--hard', 'best'" in src
    assert "'clean', '-qfd'" in src


def test_the_loop_keeps_the_best_tree_and_discards_regressions() -> None:
    """Pinned by source, because getting it backwards is silent: the run
    still produces numbers, they are just numbers for a tree nobody chose.

    Measured over six runs on the 445-test fixture before this existed:
    every run scored ~440 or 0 and never in between, because one bulk edit
    that broke `import` ended the run. Warm 311 -> 0, 0, 0; cold 0 six
    times running.
    """
    import inspect

    src = inspect.getsource(vibe_agent.migrate_codebase)
    assert "previous_best = best_passed" in src
    assert "passed > previous_best" in src, "improvements must be kept"
    assert "rejected or broke_syntax or passed < previous_best" in src, (
        "regressions, rejected trees AND syntax breakage must all be "
        "rolled back -- a shimmed or gutted tree is not a state to build "
        "on, and a tree that no longer parses is not one either")
    # Formatting-robust: the emit is line-wrapped, and asserting on the
    # exact call text made this fail for a newline.
    assert '"RESTORED"' in src and "await emit(" in src, (
        "a silent rollback would look like an agent that recovered on its "
        "own")
    # Bookkeeping, not thinking: it must not be charged to the agent.
    # Checked by ORDERING rather than by a fixed-size window -- the window
    # version broke the moment the comment above it grew.
    assert "book_started = time.monotonic()" in src
    assert (src.index("off_clock += time.monotonic() - book_started")
            > src.index("book_started = time.monotonic()")), (
        "the rollback's cost must be added to off_clock after it is timed")


def test_both_arms_get_the_history(ws) -> None:
    """Asymmetric, this would be a second difference between the arms on
    top of the skill -- and the one that decides whether a run survives a
    bad edit."""
    import inspect

    import swarm.run as runner

    src = inspect.getsource(runner.main_async)
    seed_at = src.index("ws.seed(tar)")
    warm_at = src.index("if warm:")
    assert "ws.init_history()" in src[seed_at:warm_at], (
        "init_history must run for every agent, before the warm-only branch")


def test_a_syntax_error_is_rolled_back_even_when_the_baseline_is_zero() -> None:
    """The hole the first rollback left, and the reason it never fired.

    The original rule was "roll back if this attempt scored worse than the
    best so far". On a fixture whose BASELINE is 0, a tree the agent broke
    scores exactly what the untouched tree scores, so `passed <
    previous_best` is never true. Measured on the first post-fix run: cold
    went 0, 0, 0, 0 with `IndentationError: unexpected indent` as its
    signature and not one RESTORED event was emitted.

    The pre-migration fixture parses -- its failure is a pydantic error at
    import, not a SyntaxError -- so a syntax error in a graded tree can
    only have come from the agent.
    """
    import inspect

    src = inspect.getsource(vibe_agent.migrate_codebase)
    assert "broke_syntax" in src
    assert "rejected or broke_syntax or passed < previous_best" in src
    assert 'reason=("rejected"' in src and '"syntax_error"' in src, (
        "the three rollback reasons must be distinguishable in the log")
    # And a checkpoint must never capture an unparseable tree.
    assert "not rejected and not broke_syntax and passed > previous_best" in src

    assert vibe_agent._SYNTAX_ERRORS == (
        "SyntaxError", "IndentationError", "TabError")
    # The signature really does start with the exception name -- pinned
    # against a real one captured from the pod.
    for real in ("IndentationError: unexpected indent",
                 "SyntaxError: invalid syntax"):
        assert real.startswith(vibe_agent._SYNTAX_ERRORS)
    assert not "pydantic.errors.PydanticUserError: `const` is removed".startswith(
        vibe_agent._SYNTAX_ERRORS), "the fixture's own baseline must NOT trip it"


def test_the_checkpoint_history_is_not_reachable_from_the_work_tree(ws) -> None:
    """The harness's undo must not become the agent's undo.

    Observed on r5: a cold attempt took the migration from 64 remaining
    constructs to 11, and the next attempt came back at 63 with NO
    RESTORED event -- the agent reverted the tree itself, using the git
    repo the checkpoint mechanism had put inside its checkout. Nobody
    decided to give the agents version control; it arrived as a side
    effect.
    """
    from swarm.agent_workspace import AgentWorkspace

    assert ws.history_dir == f"{ws.home}/.history"
    assert not ws.history_dir.startswith(ws.repo_path), (
        "the history must live outside the tree the agent edits")
    ws.init_history()
    issued = " ".join(ws.host.commands)
    assert f"--git-dir={ws.home}/.history" in issued
    assert f"--work-tree={ws.repo_path}" in issued
    assert "git init -q --bare" in issued
    # And nothing may create a .git inside the checkout.
    assert f"init -q {ws.repo_path}" not in issued
    assert f"cd {ws.repo_path} && git init" not in issued


def test_every_attempt_records_why_it_failed() -> None:
    """Cold's failures were undiagnosable.

    The error signature was only written on MEMORY_WRITE, which is
    warm-only, so a run where cold scored 0 on five straight attempts
    carried no record of what went wrong -- and the one number that was
    recorded, `tests_passed=0`, is the number that cannot tell "not
    started" from "broken".
    """
    import inspect

    src = inspect.getsource(vibe_agent.migrate_codebase)
    done = src[src.index('"ATTEMPT_DONE"'):]
    assert "error_signature=signature," in done[:2000]
