"""
transaction_set.py

Defines the Professional Claims 837 004010X098A1 transaction set model.
"""

from typing import List

from pydantic import Field, model_validator

from x12sdk.models import X12SegmentGroup
from x12sdk.validators import validate_segment_count

from .loops import Footer, Header, Loop1000A, Loop1000B, Loop2000A


class HealthCareClaimProfessional(X12SegmentGroup):
    """
    The HealthCare Claim - Professional transaction model (837)
    """

    header: Header
    loop_1000a: Loop1000A
    loop_1000b: Loop1000B
    loop_2000a: List[Loop2000A] = Field(min_items=1)
    footer: Footer

    @model_validator(mode="after")
    def validate_segment_count(self) -> "HealthCareClaimProfessional":
        """
        Validates the segment count conveyed in the transaction set footer, or SE segment.
        This function is only able to count "valid" segments since it is invoked as a "post" validator.
        """
        return validate_segment_count(type(self), self.__dict__)
